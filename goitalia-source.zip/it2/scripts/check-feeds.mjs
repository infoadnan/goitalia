#!/usr/bin/env node
// Verifies the OFFICIAL Roma Mobilità real-time feeds and measures how often they really update.
//   node scripts/check-feeds.mjs [samples=6] [intervalSeconds=15]
// Runs in GitHub Actions (check-feeds.yml). Prints reachability, CORS headers, size, entities, GPS fix age and observed update interval.
import { decodeFeed } from '../src/live/pb.js'
const FEEDS = { vehicles: 'https://romamobilita.it/sites/default/files/rome_rtgtfs_vehicle_positions_feed.pb', trips: 'https://romamobilita.it/sites/default/files/rome_rtgtfs_trip_updates_feed.pb' }
const N = +process.argv[2] || 6, GAP = +process.argv[3] || 15
const sleep = (s) => new Promise((r) => setTimeout(r, s * 1000)), med = (a) => (a.length ? [...a].sort((x, y) => x - y)[a.length >> 1] : null)
let failed = false
const seen = { vehicles: [], trips: [] }
for (let i = 0; i < N; i++) {
  for (const [kind, url] of Object.entries(FEEDS)) {
    try {
      const t0 = Date.now(), res = await fetch(url, { headers: { 'user-agent': 'GoItalia-feed-check' } })
      if (!res.ok) throw new Error('HTTP ' + res.status)
      const buf = new Uint8Array(await res.arrayBuffer()), f = decodeFeed(buf), now = Math.floor(Date.now() / 1000)
      const ages = f.entities.map((e) => e.vehicle?.ts && now - e.vehicle.ts).filter((x) => x != null)
      seen[kind].push(f.header.timestamp)
      if (i === 0) console.log(`[${kind}] ${url}\n   CORS header: ${res.headers.get('access-control-allow-origin') || 'none (browsers cannot read it directly -> use the proxy)'}  | ${buf.length} bytes in ${Date.now() - t0} ms | last-modified: ${res.headers.get('last-modified') || 'n/a'}`)
      console.log(`[${kind}] #${i + 1} header ts ${f.header.timestamp} (${now - f.header.timestamp}s old) | ${f.entities.length} entities${ages.length ? ` | fix age median ${med(ages)}s, newest ${Math.min(...ages)}s, >120s old: ${ages.filter((a) => a > 120).length}` : ''}`)
    } catch (e) { failed = true; console.log(`[${kind}] #${i + 1} FAILED: ${e.message}`) }
  }
  if (i < N - 1) await sleep(GAP)
}
for (const kind of Object.keys(FEEDS)) {
  const u = [...new Set(seen[kind])], gaps = u.slice(1).map((x, i) => x - u[i])
  console.log(`SUMMARY ${kind}: ${u.length} distinct feed timestamps in ${(N - 1) * GAP}s` + (gaps.length ? `; observed update interval ~${Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length)}s (min ${Math.min(...gaps)}s, max ${Math.max(...gaps)}s)` : '; no update observed (run longer or the feed is slower)'))
}
process.exit(failed ? 1 : 0)
