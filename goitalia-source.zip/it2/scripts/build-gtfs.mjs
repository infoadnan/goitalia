#!/usr/bin/env node
// Builds compact per-route JSON shards from the official Roma Mobilità static GTFS, for the GoItalia app (served from GitHub Pages).
//   node scripts/build-gtfs.mjs [--zip path-or-url] [--out gtfs]
// Run by .github/workflows/pages.yml (GitHub Actions has internet access; the browser never downloads the 100+ MB zip).
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import readline from 'node:readline'
import yauzl from 'yauzl'
import { makeLine, stopDistances, encodePolyline } from '../src/live/geo.js'
import { hav } from '../src/util.js'

const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : d }
const SRC = arg('zip', 'https://romamobilita.it/sites/default/files/rome_static_gtfs.zip')
const OUT = arg('out', 'gtfs')

function csvLine(line) {
  const out = []; let cur = '', q = false
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (q) { if (c === '"') { if (line[i + 1] === '"') { cur += '"'; i++ } else q = false } else cur += c }
    else if (c === '"') q = true
    else if (c === ',') { out.push(cur); cur = '' }
    else cur += c
  }
  out.push(cur); return out
}
async function download(url) {
  const f = path.join(os.tmpdir(), 'gtfs-' + Date.now() + '.zip')
  const res = await fetch(url, { headers: { 'user-agent': 'GoItalia-gtfs-builder' } })
  if (!res.ok) throw new Error(`download failed: HTTP ${res.status}`)
  fs.writeFileSync(f, Buffer.from(await res.arrayBuffer()))
  return f
}
function openZip(file) {
  return new Promise((res, rej) => yauzl.open(file, { lazyEntries: true, autoClose: false }, (e, z) => {
    if (e) return rej(e)
    const entries = {}
    z.on('entry', (en) => { entries[path.basename(en.fileName)] = en; z.readEntry() })
    z.on('end', () => res({ z, entries }))
    z.readEntry()
  }))
}
async function eachRow({ z, entries }, name, fn, required = true) {
  const en = entries[name]
  if (!en) { if (required) throw new Error(`${name} missing from GTFS`); return 0 }
  const stream = await new Promise((res, rej) => z.openReadStream(en, (e, s) => (e ? rej(e) : res(s))))
  const rl = readline.createInterface({ input: stream, crlfDelay: Infinity })
  let head = null, n = 0
  for await (const raw of rl) {
    const line = raw.replace(/^\uFEFF/, '')
    if (!line.trim()) continue
    if (!head) { head = csvLine(line).map((h) => h.trim()); continue }
    const v = csvLine(line), r = {}
    for (let i = 0; i < head.length; i++) r[head[i]] = v[i]
    fn(r); n++
  }
  return n
}
const secs = (t) => { if (!t) return null; const [h, m, s] = t.trim().split(':').map(Number); return h * 3600 + m * 60 + (s || 0) }

export async function build(src, out) {
  const file = /^https?:/.test(src) ? await download(src) : src
  const zip = await openZip(file)
  const routes = new Map(), stops = new Map(), trips = new Map(), shapes = new Map(), st = new Map()
  await eachRow(zip, 'routes.txt', (r) => routes.set(r.route_id, { id: r.route_id, short: (r.route_short_name || r.route_long_name || r.route_id).trim(), long: r.route_long_name || '', color: (r.route_color || '').toUpperCase(), type: +r.route_type }))
  await eachRow(zip, 'stops.txt', (r) => stops.set(r.stop_id, [r.stop_name, +(+r.stop_lat).toFixed(6), +(+r.stop_lon).toFixed(6)]))
  await eachRow(zip, 'trips.txt', (r) => trips.set(r.trip_id, { route: r.route_id, dir: r.direction_id === '' || r.direction_id == null ? null : +r.direction_id, head: r.trip_headsign || '', shape: r.shape_id || '' }))
  await eachRow(zip, 'shapes.txt', (r) => { let a = shapes.get(r.shape_id); if (!a) shapes.set(r.shape_id, (a = [])); a.push([+r.shape_pt_sequence, +r.shape_pt_lat, +r.shape_pt_lon]) }, false)
  const nst = await eachRow(zip, 'stop_times.txt', (r) => {
    let t = st.get(r.trip_id); if (!t) st.set(r.trip_id, (t = []))
    t.push([+r.stop_sequence, r.stop_id, secs(r.arrival_time) ?? secs(r.departure_time)])
  })
  zip.z.close()

  const poly = new Map()
  for (const [id, a] of shapes) { a.sort((x, y) => x[0] - y[0]); poly.set(id, a.map((p) => [p[1], p[2]])) }

  const byRoute = new Map(); let nTrips = 0, skipped = 0
  for (const [tid, rows] of st) {
    const tr = trips.get(tid)
    if (!tr || !routes.has(tr.route)) { skipped++; continue }
    rows.sort((a, b) => a[0] - b[0])
    let last = rows[0][2] ?? 0; const times = rows.map((r) => (last = r[2] ?? last))
    let R = byRoute.get(tr.route); if (!R) byRoute.set(tr.route, (R = { pats: new Map(), trips: {} }))
    const stopIds = rows.map((r) => r[1]), key = `${tr.dir}|${tr.shape}|${stopIds.join(',')}`
    let P = R.pats.get(key); if (!P) R.pats.set(key, (P = { idx: R.pats.size, dir: tr.dir, headsign: tr.head, shape: tr.shape, stops: stopIds }))
    R.trips[tid] = [P.idx, times[0], ...times.slice(1).map((t, i) => t - times[i])]; nTrips++
  }

  fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(path.join(out, 'route'), { recursive: true })
  const index = { generated: new Date().toISOString(), source: /^https?:/.test(src) ? src : path.basename(src), counts: { routes: byRoute.size, trips: nTrips, stopTimes: nst, shapes: shapes.size }, routes: {}, byShort: {} }
  for (const [rid, R] of byRoute) {
    const ro = routes.get(rid), pats = [...R.pats.values()], usedStops = {}, usedShapes = {}
    const patterns = pats.map((p) => {
      const coords = p.stops.map((s) => stops.get(s)).map((s) => (s ? [s[1], s[2]] : null))
      if (coords.some((c) => !c)) throw new Error(`route ${rid}: stop missing from stops.txt`)
      const shapePts = poly.get(p.shape)
      let dist
      if (shapePts && shapePts.length > 1) { dist = stopDistances(makeLine(shapePts), coords); usedShapes[p.shape] = encodePolyline(shapePts) }
      else { dist = [0]; for (let i = 1; i < coords.length; i++) dist.push(Math.round(dist[i - 1] + hav(coords[i - 1], coords[i]))) }
      p.stops.forEach((s) => (usedStops[s] = stops.get(s)))
      return { id: p.idx, dir: p.dir, headsign: p.headsign, shape: shapePts ? p.shape : '', stops: p.stops, dist }
    })
    fs.writeFileSync(path.join(out, 'route', encodeURIComponent(rid) + '.json'), JSON.stringify({ route: ro, patterns, stops: usedStops, shapes: usedShapes, trips: R.trips }))
    index.routes[rid] = [ro.short, ro.long, ro.color, ro.type]
    ;(index.byShort[ro.short.toUpperCase()] ||= []).push(rid)
  }
  fs.writeFileSync(path.join(out, 'index.json'), JSON.stringify(index))
  console.log(`GTFS built: ${byRoute.size} routes, ${nTrips} trips, ${nst} stop_times (${skipped} trips skipped) -> ${out}/`)
  return index
}
if (import.meta.url === `file://${process.argv[1]}`) build(SRC, OUT).catch((e) => { console.error(e); process.exit(1) })
