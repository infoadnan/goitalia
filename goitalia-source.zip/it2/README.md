# GoItalia

Live public transport for Italy. Rome gets **official Roma Mobilità GPS + trip updates**; everything else keeps working through Transitous.

## How the live part works
```
Roma Mobilità GTFS-RT (.pb)  ->  Cloudflare Worker (backend/worker.js)  ->  GoItalia (GitHub Pages)
  vehicle positions, trip updates     CORS + 8 s cache + filter by trip          decode, match to route, ETA
Roma Mobilità static GTFS (.zip) ->  GitHub Action (scripts/build-gtfs.mjs) ->  /gtfs/*.json shards next to index.html
```
* GitHub Pages cannot run servers and the official files send no CORS headers, so a tiny proxy is required. It needs **no API key** (the feeds are public). It only proxies the two configured feed URLs.
* Labels in the trip screen: **LIVE GPS** (official fix ≤ 60 s old), **GPS DELAYED / SIGNAL LOST** (older, marker dimmed), **NO LIVE GPS**, **REAL-TIME ETA** (official Trip Updates or the Transitous real-time flag), **SCHEDULED**.
* Never faked: no GPS → no bus marker. Fixes with bad coordinates, future timestamps, jumps > ~100 km/h or going backwards are rejected; fixes > 120 m from the route are flagged and not used for the next stop.

## Deploy (GitHub Pages + Cloudflare Worker)
1. **Repo**: upload everything in this folder to your GitHub repo (keep the `.github/workflows` folder). Settings → Pages → *Source: GitHub Actions*.
2. **Worker** (free Cloudflare account): Workers & Pages → Create → *Hello World* → Edit code → paste `worker.bundle.js` (or `npm run build:worker`) → Deploy. Settings → Variables: `ALLOWED_ORIGINS` = `https://YOUR-USER.github.io`.
3. **index.html**: set `rtProxy: 'https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev'` and `contact`. Commit.
4. The Action runs tests, builds the app, downloads the official GTFS (`gtfs/` is generated, not committed) and deploys. It re-runs every night so the timetable stays current.
5. Verify: Actions → *Check official … feeds* → Run workflow (prints reachability, CORS, feed age, GPS age and the real update interval). In the app: More → **Live data status** → Run check.

## Tests
`npm test` (22 tests): decoder verified against Google's official `gtfs-realtime-bindings`, server-side filter, worker (CORS, stale fallback, no open proxy), GTFS builder, route matching, next stop, ETA propagation, staleness, end to end.
