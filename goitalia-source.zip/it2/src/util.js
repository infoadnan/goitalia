export const CAT_COLOR = { bus: '1F6FB2', metro: '0B6B4F', tram: 'C2410C', train: 'B3261E', ferry: '0E7490', other: '5B6770' }
export const CATS = ['all', 'bus', 'metro', 'tram', 'train', 'ferry', 'other']
export const MODE_OF = { bus: 'BUS', metro: 'SUBWAY', tram: 'TRAM', train: 'RAIL', ferry: 'FERRY', other: 'FUNICULAR' }

export function modeCat(m) {
  m = String(m || '').toUpperCase()
  if (/BUS|COACH|TROLLEY/.test(m)) return 'bus'
  if (/SUBWAY|METRO/.test(m)) return 'metro'
  if (/TRAM/.test(m)) return 'tram'
  if (/RAIL|SUBURBAN|TRAIN/.test(m)) return 'train'
  if (/FERRY/.test(m)) return 'ferry'
  return 'other'
}
export const lineColor = (c, mode) => (/^[0-9A-Fa-f]{6}$/.test(c || '') && c.toUpperCase() !== 'FFFFFF' ? c.toUpperCase() : CAT_COLOR[modeCat(mode)])
export const onColor = (hex) => { const n = parseInt(hex, 16), l = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; return l > 0.62 ? '#111' : '#fff' }
export const lineName = (n) => { const m = /^ME([ABC]1?)$/.exec(n || ''); return m ? m[1] : n || '' }

// "S. MARIA DEL SOCCORSO (MB)" -> "S. Maria Del Soccorso (MB)"; mixed-case names are left alone
export function nice(s = '') {
  s = String(s).replace(/\s*#\s*\w+$/, '')
  if (!s || s !== s.toUpperCase() && s !== s.toLowerCase()) return s.replace(/\(([A-Za-z]{2}(?:\s?-\s?[A-Za-z]{2})*)\)/g, (m, g) => `(${g.toUpperCase()})`)
  return s.split(/(\([^)]*\))/).map((p) => (p.startsWith('(') ? p.toUpperCase() : p.toLowerCase().replace(/[\p{L}\p{N}'’.]+/gu, (w) => w[0].toUpperCase() + w.slice(1)))).join('')
}

export const hav = (a, b) => { const r = Math.PI / 180, dx = (b[1] - a[1]) * r * Math.cos(((a[0] + b[0]) / 2) * r), dy = (b[0] - a[0]) * r; return Math.hypot(dx, dy) * 6371000 }
export const walkMin = (m) => Math.max(1, Math.round(m / 80))

const TZ = 'Europe/Rome'
export const fmtTime = (d) => (d ? new Date(d).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', timeZone: TZ }) : '--:--')
export const fmtDay = (d) => new Date(d).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', timeZone: TZ })
export const minutesUntil = (iso) => Math.floor((new Date(iso) - Date.now()) / 60000)
export const romeHour = () => +new Date().toLocaleString('en-GB', { hour: 'numeric', hour12: false, timeZone: TZ }) % 24

export function decode(str, prec = 6) {
  const f = 10 ** prec; let i = 0, lat = 0, lon = 0; const out = []
  while (i < str.length) {
    for (const w of [0, 1]) {
      let r = 0, s = 0, b
      do { b = str.charCodeAt(i++) - 63; r |= (b & 31) << s; s += 5 } while (b >= 32)
      const d = r & 1 ? ~(r >> 1) : r >> 1
      if (w) lon += d; else lat += d
    }
    out.push([lat / f, lon / f])
  }
  return out
}
export const ld = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }
export const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} }
export const nearestCity = (lat, lon, cities) => cities.map((c) => ({ ...c, d: hav([lat, lon], [c.lat, c.lon]) })).sort((a, b) => a.d - b.d)[0]

export const bearing = (la1, lo1, la2, lo2) => { const r = Math.PI / 180; return (Math.atan2((lo2 - lo1) * Math.cos(la1 * r), la2 - la1) / r + 360) % 360 }

// a station can serve several modes; pick the most "special" one for its icon
export const stopCats = (modes = []) => [...new Set(modes.map(modeCat))]
export const stopCat = (modes = []) => { const c = stopCats(modes); return ['metro', 'train', 'tram', 'ferry', 'bus', 'other'].find((k) => c.includes(k)) || 'bus' }
// fallback when the API gives no modes: guess from the (Italian) stop name
export const guessCats = (name = '') => {
  const out = []
  if (/\(M[A-C]\)|\bmetro(politana)?\b|\bM[1-9]\b/i.test(name)) out.push('metro')
  if (/\bstaz(\.|ione|\.ne)?\b|\bferrovi|\bFS\b|\btermini\b|\bcentrale\b/i.test(name)) out.push('train')
  return out.length ? out : ['bus']
}
