import { makeRt } from './rt.js'
import { makeStatic } from './gtfs.js'
export const rt = makeRt()       // proxy URL comes from window.APP_CONFIG.rtProxy (index.html)
export const stat = makeStatic() // gtfs/ folder next to index.html (built by the GitHub Action)
