// Cheap server-side filtering of a GTFS-RT FeedMessage WITHOUT decoding it (so it fits Cloudflare's free CPU limit):
// walk the top-level records, keep the header and only the entities that contain a field-anchored needle.
const enc = new TextEncoder()
const varintBytes = (n) => { const o = []; while (n > 127) { o.push((n & 127) | 128); n = Math.floor(n / 128) } o.push(n); return o }
export const needle = (tagByte, text) => { const t = enc.encode(text); return new Uint8Array([tagByte, ...varintBytes(t.length), ...t]) }
export const TAG = { tripId: 0x0a, routeId: 0x2a, tuStopId: 0x22, vpStopId: 0x3a }

function includes(hay, s, e, nd) {
  const n = nd.length, first = nd[0]
  for (let i = s; i <= e - n; i++) {
    if (hay[i] !== first) continue
    let k = 1; while (k < n && hay[i + k] === nd[k]) k++
    if (k === n) return true
  }
  return false
}
const readVar = (b, i) => { let r = 0, m = 1, x; do { x = b[i++]; r += (x & 127) * m; m *= 128 } while (x & 128); return [r, i] }

export function filterFeed(buf, needles, maxEntities = 200) {
  const header = [], kept = []
  let i = 0
  while (i < buf.length) {
    const start = i, [tag, j] = readVar(buf, i), f = tag >>> 3, w = tag & 7
    if (w !== 2) throw new Error('unexpected wire type at top level')
    const [len, k] = readVar(buf, j), end = k + len
    if (end > buf.length) throw new Error('truncated feed')
    if (f === 1) header.push([start, end])
    else if (f === 2 && kept.length < maxEntities && needles.some((nd) => includes(buf, k, end, nd))) kept.push([start, end])
    i = end
  }
  const parts = [...header, ...kept], out = new Uint8Array(parts.reduce((a, [s, e]) => a + e - s, 0))
  let o = 0; for (const [s, e] of parts) { out.set(buf.subarray(s, e), o); o += e - s }
  return { body: out, total: kept.length }
}
export const headerTimestamp = (buf) => {
  let i = 0
  while (i < buf.length) {
    const [tag, j] = readVar(buf, i), f = tag >>> 3, w = tag & 7
    if (w !== 2) return null
    const [len, k] = readVar(buf, j)
    if (f === 1) { let p = k; while (p < k + len) { const [t2, q] = readVar(buf, p); if ((t2 & 7) === 0) { const [v, r] = readVar(buf, q); if (t2 >>> 3 === 3) return v; p = r } else if ((t2 & 7) === 2) { const [l2, r] = readVar(buf, q); p = r + l2 } else return null } return null }
    i = k + len
  }
  return null
}
