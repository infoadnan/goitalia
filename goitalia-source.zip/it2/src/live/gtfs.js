// Loads the static GTFS shards built by scripts/build-gtfs.mjs and matches a Transitous trip to an official GTFS trip.
import { hav } from '../util.js'
import { diag } from './rt.js'

export function makeStatic({ base, fetchImpl = (...a) => fetch(...a) } = {}) {
  base = base || (typeof location !== 'undefined' ? new URL('gtfs/', location.href).href : 'gtfs/')
  const cache = new Map()
  const getJson = (rel) => {
    if (!cache.has(rel)) cache.set(rel, fetchImpl(base + rel).then((r) => { if (!r.ok) throw new Error(`${rel}: HTTP ${r.status}`); return r.json() }).catch((e) => { cache.delete(rel); throw e }))
    return cache.get(rel)
  }
  return {
    index: async () => { const i = await getJson('index.json'); diag.staticGenerated = i.generated; return i },
    route: (rid) => getJson('route/' + encodeURIComponent(rid) + '.json'),
  }
}

// "20261126_08:15_it-rome_12345" -> ["20261126_08:15_it-rome_12345", "08:15_it-rome_12345", "it-rome_12345", "12345"]
export function tripIdCandidates(id = '') {
  const parts = String(id).split('_'), out = new Set([id])
  for (let i = 1; i < parts.length; i++) out.add(parts.slice(i).join('_'))
  return [...out]
}
const romeSecs = (iso) => { const p = new Date(iso).toLocaleTimeString('en-GB', { timeZone: 'Europe/Rome', hour12: false }).split(':').map(Number); return p[0] * 3600 + p[1] * 60 + p[2] }

// ref = {tripId, name(line short name)}, stops = Transitous trip stops [{lat, lon, departure|scheduledDeparture ...}]
// Strategy: 1) exact GTFS trip id inside the Transitous id  2) same route + start time (±2 min) + first/last stop within a few hundred metres.
export async function resolveTrip(st, ref, stops) {
  const idx = await st.index(), rids = idx.byShort[String(ref.name || '').toUpperCase()] || []
  if (!rids.length) return { ok: false, reason: 'route-not-in-gtfs' }
  const cands = tripIdCandidates(ref.tripId), shards = await Promise.all(rids.map((r) => st.route(r)))
  for (const sh of shards) for (const c of cands) if (sh.trips[c]) return { ok: true, shard: sh, tripId: c, how: 'id', index: idx }
  const first = stops[0], last = stops.at(-1), t0 = romeSecs(first.scheduledDeparture || first.departure || first.arrival || first.scheduledArrival)
  let best = null
  for (const sh of shards) for (const [tid, t] of Object.entries(sh.trips)) {
    if (Math.abs(t[1] - t0) > 120) continue
    const pat = sh.patterns[t[0]], a = sh.stops[pat.stops[0]], b = sh.stops[pat.stops.at(-1)]
    if (!a || !b) continue
    const score = hav([first.lat, first.lon], [a[1], a[2]]) + hav([last.lat, last.lon], [b[1], b[2]]) + Math.abs(t[1] - t0)
    if (hav([first.lat, first.lon], [a[1], a[2]]) < 250 && hav([last.lat, last.lon], [b[1], b[2]]) < 400 && (!best || score < best.score)) best = { score, sh, tid }
  }
  return best ? { ok: true, shard: best.sh, tripId: best.tid, how: 'time+stops', index: idx } : { ok: false, reason: 'no-matching-trip' }
}
