import { useEffect, useRef, useState } from 'react'
import { vehicleFor, tripUpdateFor, diag } from './rt.js'
import { resolveTrip } from './gtfs.js'
import { buildModel, analyse } from './engine.js'
import { rt, stat } from './instance.js'

// Official live data for one trip: matches the Transitous trip to the GTFS trip, then polls the proxy while the screen is open.
// Nothing is invented: if there is no vehicle / no fresh GPS the result says so.
export function useLiveTrip(ref0, d) {
  const [S, setS] = useState({ configured: rt.configured, phase: 'matching' })
  const model = useRef(null), prev = useRef(null), tid = useRef(null)

  useEffect(() => {
    if (!d) return
    let off = false; model.current = null; prev.current = null; tid.current = null
    setS({ configured: rt.configured, phase: 'matching' })
    resolveTrip(stat, ref0, d.stops).then((r) => {
      if (off) return
      if (!r.ok) { diag.matched = r.reason; return setS({ configured: rt.configured, phase: 'nomatch', reason: r.reason }) }
      model.current = buildModel(r.shard, r.tripId); tid.current = r.tripId; diag.matched = r.how; diag.trip = r.tripId
      setS({ configured: rt.configured, phase: rt.configured ? 'polling' : 'no-proxy', how: r.how, model: model.current })
    }).catch((e) => { if (!off) { diag.lastError = 'static: ' + e.message; setS({ configured: rt.configured, phase: 'static-error', reason: e.message }) } })
    return () => { off = true }
  }, [ref0.tripId, !!d])

  useEffect(() => {
    if (S.phase !== 'polling') return
    let timer, stopped = false, fails = 0
    const tick = async () => {
      if (stopped) return
      if (document.visibilityState === 'visible') {
        const id = tid.current
        const [v, u] = await Promise.all([rt.get('vehicles', { trip: id }), rt.get('trips', { trip: id })])
        if (stopped) return
        const now = Math.floor(Date.now() / 1000)
        const res = analyse({ model: model.current, vehicle: v.ok ? vehicleFor(v.feed, id) : null, tu: u.ok ? tripUpdateFor(u.feed, id) : null, now, feedTs: v.ok ? v.feedTs : 0, prev: prev.current })
        prev.current = res.state
        setS((s) => ({ ...s, ...res, feed: { vOk: v.ok, tOk: u.ok, reason: v.ok ? null : v.reason, stale: v.ok ? v.stale : 0, feedAge: v.ok && v.feedTs ? now - v.feedTs : null }, updated: Date.now() }))
        fails = v.ok || u.ok ? 0 : fails + 1
      }
      timer = setTimeout(tick, Math.min(60000, 10000 * 2 ** Math.min(fails, 3)))   // 10 s, backing off to 60 s on errors
    }
    tick()
    return () => { stopped = true; clearTimeout(timer) }
  }, [S.phase])

  return S
}
