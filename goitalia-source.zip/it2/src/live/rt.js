// Client side of the live data: talks to the GoItalia proxy (backend/worker.js), decodes GTFS-RT, keeps diagnostics. Never invents data.
import { decodeFeed } from './pb.js'

export const diag = { proxy: false, calls: 0, ok: 0, lastOk: 0, lastError: '', vehiclesFeedTs: 0, tripsFeedTs: 0, stale: 0, matched: '', staticGenerated: '', trip: '' }

export function makeRt({ base = (typeof window !== 'undefined' && window.APP_CONFIG?.rtProxy) || '', fetchImpl = (...a) => fetch(...a), timeoutMs = 8000 } = {}) {
  base = String(base).replace(/\/$/, '')
  diag.proxy = !!base
  return {
    configured: !!base,
    // kind: 'vehicles' | 'trips'; params: { trip } | { route } | { stop }
    async get(kind, params) {
      if (!base) return { ok: false, reason: 'no-proxy' }
      diag.calls++
      const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null, to = ctl && setTimeout(() => ctl.abort(), timeoutMs)
      try {
        const res = await fetchImpl(`${base}/rt/${kind}?${new URLSearchParams(params)}`, ctl ? { signal: ctl.signal } : undefined)
        if (!res.ok) throw new Error('HTTP ' + res.status)
        const feed = decodeFeed(new Uint8Array(await res.arrayBuffer()))
        const stale = +res.headers.get('x-stale') || 0
        diag.ok++; diag.lastOk = Date.now(); diag.stale = stale; diag.lastError = ''
        if (feed.header.timestamp) diag[kind === 'vehicles' ? 'vehiclesFeedTs' : 'tripsFeedTs'] = feed.header.timestamp
        return { ok: true, feed, feedTs: feed.header.timestamp || 0, stale, fetchedAt: +res.headers.get('x-fetched-at') || 0 }
      } catch (e) {
        const reason = e?.name === 'AbortError' ? 'timeout' : 'unreachable'
        diag.lastError = `${reason}: ${e?.message || e}`
        return { ok: false, reason, error: String(e?.message || e) }
      } finally { if (to) clearTimeout(to) }
    },
  }
}
// pick this trip's entities out of a (pre-filtered, but re-verified) feed
export const vehicleFor = (feed, tripId) => feed?.entities.find((e) => e.vehicle?.trip?.tripId === tripId)?.vehicle || null
export const tripUpdateFor = (feed, tripId) => feed?.entities.find((e) => e.tripUpdate?.trip?.tripId === tripId)?.tripUpdate || null
