// Live-trip analysis: validates GPS, matches it to the route, finds the next stop and builds ETAs from official Trip Updates.
// Pure functions (no I/O, no clock): everything takes `now` so it is unit-testable. Times are epoch seconds unless noted.
import { makeLine, snap, pointAt } from './geo.js'
import { decode } from '../util.js'

export const TH = {
  FRESH: 60,        // GPS fix newer than this = LIVE
  DELAYED: 150,     // older than FRESH but still shown as "delayed"
  STALE: 600,       // older than this = no usable GPS
  FUTURE: 120,      // fix timestamped in the future by more than this = invalid clock
  FEED_STALE: 180,  // feed header older than this = feed not updating
  MAX_SPEED: 28,    // m/s (~100 km/h) implied between two fixes; more = outlier
  OFF_ROUTE: 120,   // metres away from the route shape
}
export const STATUS = { INCOMING_AT: 0, STOPPED_AT: 1, IN_TRANSIT_TO: 2 } // gtfs-realtime VehicleStopStatus

/* ---------- time helpers ---------- */
function romeOffsetMin(utcMs) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: 'Europe/Rome', hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(utcMs).map((x) => [x.type, x.value]))
  return (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - utcMs) / 60000
}
// 00:00 Europe/Rome of a service date (YYYYMMDD), in ms. (GTFS counts from "noon minus 12 h"; identical except on the two DST nights.)
export function romeMidnightMs(ymd) {
  const y = +ymd.slice(0, 4), m = +ymd.slice(4, 6) - 1, d = +ymd.slice(6, 8)
  return Date.UTC(y, m, d) - romeOffsetMin(Date.UTC(y, m, d, 12)) * 60000
}
export const romeYmd = (ms) => new Date(ms).toLocaleDateString('sv-SE', { timeZone: 'Europe/Rome' }).replace(/-/g, '')
// when the feed gives no start_date: pick today/yesterday so that the first stop time is closest to now
export function guessServiceDate(firstSec, nowMs) {
  const today = romeYmd(nowMs), yest = romeYmd(nowMs - 864e5)
  const d = (ymd) => Math.abs(romeMidnightMs(ymd) + firstSec * 1000 - nowMs)
  return d(yest) < d(today) ? yest : today
}

/* ---------- static model of one trip ---------- */
export function buildModel(shard, tripId) {
  const t = shard.trips[tripId]
  if (!t) return null
  const pat = shard.patterns[t[0]], secs = [t[1]]
  for (let k = 2; k < t.length; k++) secs.push(secs[k - 2] + t[k])
  const stops = pat.stops.map((id, i) => ({ id, name: shard.stops[id]?.[0] || id, lat: shard.stops[id]?.[1], lon: shard.stops[id]?.[2], dist: pat.dist[i], sec: secs[i] }))
  const poly = shard.shapes[pat.shape]
  const shapeOk = !!poly
  const line = makeLine(shapeOk ? decode(poly, 5) : stops.map((s) => [s.lat, s.lon]))
  return { tripId, route: shard.route, pat, stops, line, shapeOk }
}

/* ---------- GPS quality ---------- */
const inItaly = (la, lo) => la > 35.4 && la < 47.2 && lo > 6.5 && lo < 18.8
export function gpsQuality(v, now, feedTs) {
  if (!v || !v.pos) return { status: 'none', reason: 'no-vehicle' }
  const { lat, lon } = v.pos
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || (lat === 0 && lon === 0) || !inItaly(lat, lon)) return { status: 'invalid', reason: 'bad-coordinates' }
  const ts = v.ts || feedTs
  if (!ts) return { status: 'invalid', reason: 'no-timestamp' }
  const age = now - ts
  if (age < -TH.FUTURE) return { status: 'invalid', reason: 'future-timestamp', age }
  const a = Math.max(0, age)
  const tsSource = v.ts ? 'vehicle' : 'feed'
  if (a <= TH.FRESH) return { status: 'live', age: a, tsSource }
  if (a <= TH.DELAYED) return { status: 'delayed', age: a, tsSource }
  if (a <= TH.STALE) return { status: 'stale', age: a, tsSource, reason: 'old-fix' }
  return { status: 'none', reason: 'too-old', age: a }
}

/* ---------- ETAs from an official TripUpdate (propagating delays as the GTFS-RT spec says) ---------- */
export function buildEtas(model, tu, nowMs, startYmd) {
  const n = model.stops.length
  const ymd = startYmd || tu?.trip?.startDate || guessServiceDate(model.stops[0].sec, nowMs)
  const mid = romeMidnightMs(ymd)
  const sched = model.stops.map((s) => mid + s.sec * 1000)
  const base = sched.map((t) => ({ time: t, src: 'scheduled' }))
  if (!tu) return { etas: base, cancelled: false, official: false, ymd }
  if (tu.trip?.rel === 3) return { etas: base, cancelled: true, official: true, ymd }

  const upd = new Map(); let ptr = 0
  for (const u of tu.stu || []) {
    let j = -1
    if (u.stopId) for (let k = ptr; k < n; k++) if (model.stops[k].id === u.stopId) { j = k; break }
    if (j < 0) continue
    ptr = j
    const ev = u.arrival?.time || u.arrival?.delay != null || u.departure?.time || u.departure?.delay != null ? (u.arrival && (u.arrival.time || u.arrival.delay != null) ? u.arrival : u.departure) : null
    if (u.rel === 1) { upd.set(j, { skipped: true }); continue }
    if (!ev) continue
    upd.set(j, { time: ev.time ? ev.time * 1000 : sched[j] + ev.delay * 1000 })
  }
  let cur = null, any = false
  const etas = []
  for (let i = 0; i < n; i++) {
    const u = upd.get(i)
    if (u?.skipped) { etas.push({ time: cur != null ? sched[i] + cur : sched[i], src: 'skipped', skipped: true }); continue }
    if (u) { cur = u.time - sched[i]; any = true; etas.push({ time: u.time, src: 'realtime' }) }
    else if (cur != null) etas.push({ time: sched[i] + cur, src: 'realtime-propagated' })
    else if (tu.delay != null && !upd.size) { etas.push({ time: sched[i] + tu.delay * 1000, src: 'realtime-propagated' }); any = true }
    else etas.push({ time: sched[i], src: 'scheduled' })
  }
  for (let i = 1; i < n; i++) if (etas[i].time < etas[i - 1].time && !etas[i].skipped) etas[i] = { ...etas[i], time: etas[i - 1].time } // never go back in time
  return { etas, cancelled: false, official: any, ymd }
}

/* ---------- put it together ---------- */
// prev = state returned by the previous call (for jump / backwards filtering and the search window)
export function analyse({ model, vehicle, tu, now, feedTs, prev }) {
  const nowMs = now * 1000
  const q = gpsQuality(vehicle, now, feedTs)
  const out = { gps: q, vehicle: null, nextIdx: null, atStop: false, conflict: false, off: [], state: prev || null }

  if (['live', 'delayed', 'stale'].includes(q.status)) {
    const v = vehicle, p = [v.pos.lat, v.pos.lon], ts = v.ts || feedTs
    const dt = prev ? Math.max(1, ts - prev.ts) : 0
    const win = prev ? { from: Math.max(0, prev.s - 60), to: prev.s + Math.max(400, (v.pos.speed || 8) * (dt + 10) * 1.6 + 200) } : {}
    let r = snap(model.line, p, { ...win, heading: v.pos.bearing, speed: v.pos.speed })
    if (!r || r.lateral > TH.OFF_ROUTE) r = snap(model.line, p, { heading: v.pos.bearing, speed: v.pos.speed }) || r
    let sample = { lat: p[0], lon: p[1], bearing: v.pos.bearing, speed: v.pos.speed, ts, s: r.s, lateral: r.lateral, offRoute: r.lateral > TH.OFF_ROUTE }
    if (prev && sample.ts === prev.ts) sample = prev                                   // same fix as before
    else if (prev && !sample.offRoute) {
      const jump = (sample.s - prev.s) / dt
      if (sample.s < prev.s - 80 || jump > TH.MAX_SPEED) { out.off.push('outlier'); sample = { ...prev, rejected: true } }   // GPS jitter / teleport: keep last good
    }
    out.vehicle = sample; out.state = sample
  }

  const v = out.vehicle
  const geo = v && !v.offRoute ? (() => { const i = model.stops.findIndex((s) => s.dist > v.s + 15); return i < 0 ? model.stops.length - 1 : i })() : null
  let official = null
  if (vehicle?.stopId && ['live', 'delayed', 'stale'].includes(q.status)) {
    let best = -1, bd = Infinity
    model.stops.forEach((s, i) => { if (s.id === vehicle.stopId) { const d = geo == null ? i : Math.abs(i - geo); if (d < bd) { bd = d; best = i } } })
    if (best >= 0) official = { idx: best, stopped: vehicle.status === STATUS.STOPPED_AT }
  }
  if (official && geo != null && Math.abs(official.idx - geo) > 1) { out.conflict = true; out.nextIdx = geo }       // official disagrees with the route geometry: trust geometry
  else if (official) { out.nextIdx = official.idx; out.atStop = official.stopped }
  else if (geo != null) { out.nextIdx = geo; out.atStop = model.stops.some((s) => Math.abs(s.dist - v.s) <= 15 && (v.speed ?? 0) < 1) }

  const e = buildEtas(model, tu, nowMs)
  out.etas = e.etas; out.etaSrc = e.cancelled ? 'cancelled' : e.official ? 'realtime' : 'scheduled'; out.cancelled = e.cancelled; out.ymd = e.ymd
  return out
}
