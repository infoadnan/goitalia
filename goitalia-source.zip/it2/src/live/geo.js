import { hav, bearing } from '../util.js'
const rad = Math.PI / 180

// polyline = [[lat, lon], ...]
export function makeLine(pts) {
  const cum = [0]
  for (let i = 1; i < pts.length; i++) cum[i] = cum[i - 1] + hav(pts[i - 1], pts[i])
  return { pts, cum, len: cum[cum.length - 1] }
}
function seg(a, b, p) {
  const kx = Math.cos(a[0] * rad) * 111320, ky = 110540
  const bx = (b[1] - a[1]) * kx, by = (b[0] - a[0]) * ky, px = (p[1] - a[1]) * kx, py = (p[0] - a[0]) * ky
  const L2 = bx * bx + by * by, t = L2 ? Math.max(0, Math.min(1, (px * bx + py * by) / L2)) : 0
  return { t, d: Math.hypot(px - bx * t, py - by * t), len: Math.sqrt(L2) }
}
export const angDiff = (a, b) => { const d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d }

// Snap a point onto the route line (not straight-line distance to stops).
// from/to restrict the search to a window of distance-along-route; heading penalises segments that run the other way.
export function snap(line, p, { from = 0, to = line.len, heading = null, speed = 0 } = {}) {
  let best = null
  for (let i = 1; i < line.pts.length; i++) {
    if (line.cum[i] < from) continue
    if (line.cum[i - 1] > to) break
    const r = seg(line.pts[i - 1], line.pts[i], p)
    let cost = r.d
    if (heading != null && speed > 1.5 && r.len > 3 && angDiff(bearing(...line.pts[i - 1], ...line.pts[i]), heading) > 100) cost += 60
    if (!best || cost < best.cost) best = { cost, lateral: r.d, s: line.cum[i - 1] + r.t * (line.cum[i] - line.cum[i - 1]), i }
  }
  return best
}
export function pointAt(line, s) {
  s = Math.max(0, Math.min(line.len, s))
  let i = 1; while (i < line.cum.length - 1 && line.cum[i] < s) i++
  const a = line.pts[i - 1], b = line.pts[i] || a, k = (s - line.cum[i - 1]) / (line.cum[i] - line.cum[i - 1] || 1)
  return { lat: a[0] + (b[0] - a[0]) * k, lon: a[1] + (b[1] - a[1]) * k, bearing: bearing(a[0], a[1], b[0], b[1]) }
}
// distance along the line for each stop, in order (monotonic)
export function stopDistances(line, stops /* [[lat,lon]] */) {
  const out = []; let from = 0
  for (const p of stops) {
    const r = snap(line, p, { from: Math.max(0, from - 5), to: from + 8000 }) || snap(line, p, { from: Math.max(0, from - 5) }) || { s: from }
    out.push(Math.round(r.s)); from = r.s
  }
  return out
}

// Google polyline (precision 5)
export function encodePolyline(pts, prec = 5) {
  const f = 10 ** prec; let pl = 0, pn = 0, o = ''
  const e = (v) => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 32) { s += String.fromCharCode((32 | (v & 31)) + 63); v >>= 5 } return s + String.fromCharCode(v + 63) }
  for (const [la, lo] of pts) { const a = Math.round(la * f), b = Math.round(lo * f); o += e(a - pl) + e(b - pn); pl = a; pn = b }
  return o
}
