// Minimal GTFS-Realtime (protobuf) decoder. Only the fields GoItalia needs; verified against the official bindings in /test.
const td = new TextDecoder()

function varint(b, i) {
  let p = i, bytes = 0
  while (b[p + bytes] & 0x80) { bytes++; if (bytes > 9) throw new Error('bad varint') }
  bytes++
  if (bytes <= 7) { let r = 0, mul = 1; for (let k = 0; k < bytes; k++) { r += (b[p + k] & 0x7f) * mul; mul *= 128 } return [r, p + bytes] }
  let v = 0n
  for (let k = 0; k < bytes; k++) v |= BigInt(b[p + k] & 0x7f) << BigInt(7 * k)
  return [Number(BigInt.asIntN(64, v)), p + bytes]
}

export function* fields(b, s = 0, e = b.length) {
  let i = s
  while (i < e) {
    const [tag, j] = varint(b, i); i = j
    const f = tag >>> 3, w = tag & 7
    if (w === 0) { const [v, k] = varint(b, i); i = k; yield [f, w, v] }
    else if (w === 2) { const [l, k] = varint(b, i); i = k; if (i + l > e) throw new Error('truncated'); yield [f, w, b.subarray(i, i + l)]; i += l }
    else if (w === 5) { yield [f, w, b.subarray(i, i + 4)]; i += 4 }
    else if (w === 1) { yield [f, w, b.subarray(i, i + 8)]; i += 8 }
    else throw new Error('unsupported wire type ' + w)
  }
}
const f32 = (x) => new DataView(x.buffer, x.byteOffset, 4).getFloat32(0, true)
const str = (x) => td.decode(x)

function event(b) { const o = {}; for (const [f, , v] of fields(b)) { if (f === 1) o.delay = v; else if (f === 2) o.time = v; else if (f === 3) o.uncertainty = v } return o }
function tripDesc(b) {
  const o = {}
  for (const [f, , v] of fields(b)) { if (f === 1) o.tripId = str(v); else if (f === 2) o.startTime = str(v); else if (f === 3) o.startDate = str(v); else if (f === 4) o.rel = v; else if (f === 5) o.routeId = str(v); else if (f === 6) o.directionId = v }
  return o
}
function vehDesc(b) { const o = {}; for (const [f, , v] of fields(b)) { if (f === 1) o.id = str(v); else if (f === 2) o.label = str(v); else if (f === 3) o.plate = str(v) } return o }
function stu(b) {
  const o = {}
  for (const [f, , v] of fields(b)) { if (f === 1) o.seq = v; else if (f === 2) o.arrival = event(v); else if (f === 3) o.departure = event(v); else if (f === 4) o.stopId = str(v); else if (f === 5) o.rel = v }
  return o
}
function tripUpdate(b) {
  const o = { stu: [] }
  for (const [f, , v] of fields(b)) { if (f === 1) o.trip = tripDesc(v); else if (f === 2) o.stu.push(stu(v)); else if (f === 3) o.vehicle = vehDesc(v); else if (f === 4) o.timestamp = v; else if (f === 5) o.delay = v }
  return o
}
function position(b) {
  const o = {}
  for (const [f, , v] of fields(b)) { if (f === 1) o.lat = f32(v); else if (f === 2) o.lon = f32(v); else if (f === 3) o.bearing = f32(v); else if (f === 5) o.speed = f32(v) }
  return o
}
function vehiclePos(b) {
  const o = {}
  for (const [f, , v] of fields(b)) {
    if (f === 1) o.trip = tripDesc(v); else if (f === 2) o.pos = position(v); else if (f === 3) o.seq = v; else if (f === 4) o.status = v
    else if (f === 5) o.ts = v; else if (f === 7) o.stopId = str(v); else if (f === 8) o.vehicle = vehDesc(v); else if (f === 9) o.occupancy = v
  }
  return o
}

export function decodeFeed(buf) {
  const out = { header: {}, entities: [] }
  for (const [f, , v] of fields(buf)) {
    if (f === 1) { for (const [hf, , hv] of fields(v)) { if (hf === 1) out.header.version = str(hv); else if (hf === 2) out.header.incrementality = hv; else if (hf === 3) out.header.timestamp = hv } }
    else if (f === 2) {
      const e = {}
      for (const [ef, , ev] of fields(v)) { if (ef === 1) e.id = str(ev); else if (ef === 2) e.deleted = !!ev; else if (ef === 3) e.tripUpdate = tripUpdate(ev); else if (ef === 4) e.vehicle = vehiclePos(ev) }
      out.entities.push(e)
    }
  }
  return out
}
