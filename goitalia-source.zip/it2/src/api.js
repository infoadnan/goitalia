// Small polite client for the public Transitous (MOTIS) API: cache, de-dup, timeout, max 3 parallel calls.
const BASE = (window.APP_CONFIG?.apiBase || 'https://api.transitous.org').replace(/\/$/, '')
const cache = new Map(), inflight = new Map(), queue = []
let active = 0
const slot = () => new Promise((res) => { const go = () => (active < 3 ? (active++, res()) : queue.push(go)); go() })
const release = () => { active--; queue.shift()?.() }

export function get(path, params = {}, { ttl = 0, timeout = 12000 } = {}) {
  const url = new URL(BASE + path)
  Object.entries(params).forEach(([k, v]) => v != null && url.searchParams.set(k, v))
  const key = url.toString()
  const hit = cache.get(key)
  if (hit && Date.now() - hit.t < ttl * 1000) return Promise.resolve(hit.v)
  if (inflight.has(key)) return inflight.get(key)
  const p = (async () => {
    await slot()
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), timeout)
      const res = await fetch(key, { signal: ctl.signal })
      clearTimeout(to)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const v = await res.json()
      if (ttl) cache.set(key, { t: Date.now(), v })
      return v
    } finally { release(); inflight.delete(key) }
  })()
  inflight.set(key, p)
  return p
}
