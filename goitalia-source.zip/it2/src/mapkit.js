import maplibregl from 'maplibre-gl'
import { hav, CAT_COLOR, onColor, bearing } from './util.js'
import { GLYPH, STOPK } from './glyphs.js'

export const STYLES = {
  light: ['https://basemaps.cartocdn.com/gl/positron-gl-style/style.json', 'https://tiles.openfreemap.org/styles/positron'],
  dark: ['https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json', 'https://tiles.openfreemap.org/styles/dark'],
}
const EMPTY = { type: 'FeatureCollection', features: [] }

// flat vector badges drawn as SVG -> registered as map images (re-run after every style change)
function addSvg(m, name, svg, w, h) {
  if (m.hasImage(name)) return
  const img = new Image(w, h)
  img.onload = () => { try { if (!m.hasImage(name)) m.addImage(name, img, { pixelRatio: 2 }) } catch {} }
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg)
}
const S = (w, h, body) => `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${body}</svg>`
function vectorImages(m, dark) {
  addSvg(m, 'arrow', S(40, 40, '<path d="M20 5L33 33 20 26.5 7 33z" fill="#ffffff" stroke="rgba(0,0,0,.4)" stroke-width="3" stroke-linejoin="round"/>'), 40, 40)
  for (const cat of Object.keys(CAT_COLOR)) {
    const g = GLYPH[cat], c = '#' + CAT_COLOR[cat]
    // vehicle: round badge, glyph exactly centred (24-grid glyph scaled to 0.62 -> 14.9 px, offset 4.55)
    const veh = (fill, ring) => S(76, 76, `<circle cx="38" cy="38" r="34" fill="${fill}" stroke="${ring}" stroke-width="5"/><g transform="translate(19 19) scale(1.583)" fill="#fff">${g}</g>`)
    addSvg(m, `v-${cat}-rt`, veh(c, '#ffffff'), 76, 76)
    addSvg(m, `v-${cat}-tt`, veh(c + 'b0', dark ? '#6f7d75' : '#aab6af'), 76, 76)
    // stop: map pin with the mode glyph inside the head
    addSvg(m, `s-${cat}`, S(60, 72, `<path d="M30 70C30 70 56 48 56 26a26 26 0 1 0-52 0c0 22 26 44 26 44z" fill="${c}" stroke="#ffffff" stroke-width="4"/><g transform="translate(13.2 9.2) scale(1.4)" fill="#fff">${g}</g>`), 60, 72)
  }
}
export const fc = (features) => ({ type: 'FeatureCollection', features })
export const reduced = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

export function addLayers(m, dark) {
  if (!m.getSource('route')) {
    m.addSource('route', { type: 'geojson', data: EMPTY })
    m.addLayer({ id: 'rc', type: 'line', source: 'route', filter: ['!=', ['get', 'walk'], true], layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': dark ? '#0b0f0d' : '#ffffff', 'line-width': 11 } })
    m.addLayer({ id: 'rt', type: 'line', source: 'route', filter: ['!=', ['get', 'walk'], true], layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': ['get', 'color'], 'line-width': 6.5 } })
    m.addSource('arrows', { type: 'geojson', data: EMPTY })
    m.addLayer({ id: 'ra', type: 'symbol', source: 'arrows', layout: { 'icon-image': 'arrow', 'icon-size': 0.8, 'icon-rotate': ['get', 'br'], 'icon-rotation-alignment': 'map', 'icon-pitch-alignment': 'map', 'icon-allow-overlap': true, 'icon-ignore-placement': true } })
    m.addLayer({ id: 'rw', type: 'line', source: 'route', filter: ['==', ['get', 'walk'], true], paint: { 'line-color': dark ? '#c4cdc8' : '#46544d', 'line-width': 4, 'line-dasharray': [0.4, 1.8] }, layout: { 'line-cap': 'round' } })
  }
  vectorImages(m, dark)
  if (!m.getSource('stops')) {
    m.addSource('stops', { type: 'geojson', data: EMPTY })
    m.addLayer({ id: 'stops', type: 'symbol', source: 'stops', minzoom: 14, layout: { 'icon-image': ['concat', 's-', ['get', 'cat']], 'icon-size': ['interpolate', ['linear'], ['zoom'], 14, 0.5, 18, 0.85], 'icon-anchor': 'bottom', 'icon-allow-overlap': true } })
  }
}

// heading arrows every ~1/10 of the route (at least 90 m apart)
function arrowPoints(features) {
  const out = []
  for (const f of features) {
    if (f.properties?.walk) continue
    const c = f.geometry.coordinates, d = cum(c), L = d[d.length - 1]
    if (!(L > 0)) continue
    const gap = Math.max(90, L / 10)
    for (let t = gap / 2, i = 1; t < L; t += gap) {
      while (i < d.length - 1 && d[i] < t) i++
      const k = (t - d[i - 1]) / (d[i] - d[i - 1] || 1), a = c[i - 1], b = c[i]
      out.push({ type: 'Feature', properties: { br: bearing(a[1], a[0], b[1], b[0]) }, geometry: { type: 'Point', coordinates: [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k] } })
    }
  }
  return fc(out)
}
const setArrows = (m, features) => m.getSource('arrows')?.setData(features ? arrowPoints(features) : fc([]))

// reveal a polyline progressively (a short "draw-in")
let token = 0
const cum = (c) => { const o = [0]; for (let i = 1; i < c.length; i++) o[i] = o[i - 1] + hav([c[i - 1][1], c[i - 1][0]], [c[i][1], c[i][0]]); return o }
function slice(c, k) {
  const d = cum(c), t = d[d.length - 1] * k; let i = 1
  while (i < d.length - 1 && d[i] < t) i++
  const f = Math.min(1, Math.max(0, (t - d[i - 1]) / (d[i] - d[i - 1] || 1)))
  return [...c.slice(0, i), [c[i - 1][0] + (c[i][0] - c[i - 1][0]) * f, c[i - 1][1] + (c[i][1] - c[i - 1][1]) * f]]
}
export function showRoute(m, features, animate = true) {
  const my = ++token, src = m?.getSource('route')
  if (!src) return
  setArrows(m, null)
  if (!animate || reduced() || !features.length) { src.setData(fc(features)); setArrows(m, features); return }
  const lens = features.map((f) => { const d = cum(f.geometry.coordinates); return d[d.length - 1] || 1 }), sum = lens.reduce((a, b) => a + b, 0), t0 = performance.now()
  const step = (now) => {
    if (my !== token) return
    const p = Math.min(1, (now - t0) / 650), e = 1 - (1 - p) ** 3
    let rem = e * sum; const out = []
    features.forEach((f, i) => { if (rem <= 0) return; out.push({ ...f, geometry: { type: 'LineString', coordinates: slice(f.geometry.coordinates, Math.min(1, rem / lens[i])) } }); rem -= lens[i] })
    src.setData(fc(p < 1 ? out : features))
    if (p < 1) requestAnimationFrame(step); else setArrows(m, features)
  }
  requestAnimationFrame(step)
}
export const clearRoute = (m) => { token++; m?.getSource('route')?.setData(EMPTY); setArrows(m, null) }

export function fitPts(m, pts, pad) {
  if (!pts.length) return
  const b = new maplibregl.LngLatBounds()
  pts.forEach(([la, lo]) => b.extend([lo, la]))
  m.fitBounds(b, { padding: pad, maxZoom: 16, duration: reduced() ? 0 : 700 })
}

export function el(cls, html = '') { const d = document.createElement('div'); d.className = cls; d.innerHTML = html; return d }
export const marker = (m, node, lat, lon) => new maplibregl.Marker({ element: node }).setLngLat([lon, lat]).addTo(m)

// vehicle marker: line-number pill + a wedge that points where the vehicle is heading
export function vehEl(name, color, rt) {
  const el = document.createElement('div')
  el.className = 'vm' + (rt ? ' rt' : '')
  el.style.setProperty('--c', '#' + color); el.style.setProperty('--t', onColor(color))
  el.innerHTML = '<span class="vm-w"></span><b></b>'
  el.querySelector('b').textContent = name || '•'
  const w = el.querySelector('.vm-w')
  return { el, rot: (deg) => { if (Number.isFinite(deg)) w.style.transform = `rotate(${deg}deg)` } }
}
