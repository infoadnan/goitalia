import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import maplibregl from 'maplibre-gl'
import { get } from './api.js'
import { t, setLang } from './i18n.js'
import { I, Glyph } from './icons.jsx'
import { GLYPH, STOPK } from './glyphs.js'
import { addLayers, STYLES, showRoute, clearRoute, fitPts, fc, el, marker, reduced, vehEl } from './mapkit.js'
import { CATS, CAT_COLOR, MODE_OF, modeCat, lineColor, onColor, lineName, nice, hav, walkMin, fmtTime, fmtDay, minutesUntil, romeHour, decode, ld, sv, nearestCity, bearing, stopCat, stopCats, guessCats } from './util.js'

const CFG = { RADIUS: 2000, REFRESH: 5,
  // [how many, max metres] of the nearest stops to keep for every transport type
  PICK: { bus: [6, 600], metro: [3, 1800], train: [2, 2000], tram: [2, 1000], ferry: [1, 2000], other: [1, 1000] }, VEH: 20, CENTER: [41.8902, 12.4922] }
const contact = window.APP_CONFIG?.contact || ''
const CITIES = [
  { n: 'Rome', lat: 41.9028, lon: 12.4964, ops: [['ATAC', 'https://www.atac.roma.it'], ['Trenitalia', 'https://www.trenitalia.com']] },
  { n: 'Milan', lat: 45.4642, lon: 9.19, ops: [['ATM', 'https://www.atm.it'], ['Trenitalia', 'https://www.trenitalia.com']] },
  { n: 'Naples', lat: 40.8518, lon: 14.2681, ops: [['ANM', 'https://www.anm.it'], ['EAV', 'https://www.eavsrl.it']] },
  { n: 'Turin', lat: 45.0703, lon: 7.6869, ops: [['GTT', 'https://www.gtt.to.it'], ['Trenitalia', 'https://www.trenitalia.com']] },
  { n: 'Genoa', lat: 44.4056, lon: 8.9463, ops: [['AMT Genova', 'https://www.amt.genova.it'], ['Trenitalia', 'https://www.trenitalia.com']] },
  { n: 'Catania', lat: 37.5079, lon: 15.087, ops: [['AMT Catania', 'https://www.amt.ct.it'], ['FCE Circumetnea', 'https://www.circumetnea.it']] },
]
const NAV = [['home', 'dirs', 'Directions'], ['nearby', 'loc', 'Stations'], ['lines', 'lines', 'Lines'], ['tickets', 'ticket', 'Tickets'], ['more', 'more', 'More']]

/* ---------- small pieces ---------- */
const Chip = ({ name, color, mode, sm }) => {
  const c = lineColor(color, mode), Ic = I[modeCat(mode)] || I.bus
  return <span className={'lc' + (sm ? ' sm' : '')} style={{ background: '#' + c, color: onColor(c) }}>{!sm && <Ic />}{lineName(name)}</span>
}
const Roll = ({ k, children, cls }) => <b key={k} className={'roll ' + (cls || '')}>{children}</b>

function Delay({ sched, actual, rt, cancelled }) {
  if (cancelled) return <span className="delay cx">{t('Cancelled')}</span>
  if (!rt) return null
  const m = Math.round((new Date(actual) - new Date(sched || actual)) / 60000)
  return m >= 1 ? <span className="delay late">+{m} {t('min')}</span> : m <= -1 ? <span className="delay ok">−{-m} {t('min')}</span> : <span className="delay ok">{t('On time')}</span>
}
function When({ x }) {
  const p = x.place || x, dep = p.departure || p.arrival, sd = p.scheduledDeparture || p.scheduledArrival, m = minutesUntil(dep), rt = x.realTime
  const shifted = rt && Math.abs(new Date(dep) - new Date(sd)) >= 60000
  return (
    <div className="tm">
      {m <= 0 ? <span className={'minutes' + (rt ? ' is-rt' : '')}>{rt && <I.live />}<Roll k="n">{t('now')}</Roll></span>
        : m < 60 ? <span className={'minutes' + (rt ? ' is-rt' : '')}>{rt && <I.live />}<Roll k={m}>{m}</Roll><small>{t('min')}</small></span>
        : <span className="minutes">{fmtTime(dep)}</span>}
      {shifted && <span className="small muted">{fmtTime(dep)} <s>{fmtTime(sd)}</s></span>}
      <Delay sched={sd} actual={dep} rt={rt} cancelled={p.cancelled || x.cancelled} />
    </div>
  )
}
function groupTimes(times, cat) {
  const g = new Map()
  for (const x of times || []) {
    if (cat !== 'all' && modeCat(x.mode) !== cat) continue
    if (minutesUntil(x.place.departure || x.place.arrival) < -1) continue
    const k = (x.displayName || x.routeShortName || x.tripShortName) + '|' + (x.headsign || '')
    if (!g.has(k)) g.set(k, [])
    g.get(k).push(x)
  }
  return [...g.values()]
}
function DepRow({ list, onOpen, i = 0 }) {
  const x = list[0], p = x.place || {}
  const later = list.slice(1, 3).map((y) => { const m = minutesUntil(y.place.departure || y.place.arrival); return m < 60 ? Math.max(0, m) : fmtTime(y.place.departure) })
  return (
    <button className="dep" style={{ '--i': i }} onClick={() => onOpen(x)}>
      <Chip name={x.displayName || x.routeShortName || x.tripShortName} color={x.routeColor} mode={x.mode} />
      <div className="hd">{nice(x.headsign || x.tripTo?.name || '')}
        <small>{[x.agencyName && nice(x.agencyName), p.track && `${t('Platform')} ${p.track}`, later.length && `${t('then')} ${later.join(', ')}′`].filter(Boolean).join(' · ')}</small></div>
      <When x={x} />
    </button>
  )
}
function Modes({ cats, value, onChange }) {
  return (
    <div className="chips" role="group">
      {CATS.filter((c) => c === 'all' || cats.has(c)).map((c) => { return <button key={c} className="chp" aria-pressed={value === c} onClick={() => onChange(c)}>{c !== 'all' && (() => { const Ic = I[c]; return <Ic /> })()}{t(c === 'all' ? 'All' : c[0].toUpperCase() + c.slice(1))}</button> })}
    </div>
  )
}
const StopIcon = ({ cat }) => <Glyph k={STOPK[cat] || 'busstop'} />
const Skel = ({ n = 3 }) => <div className="skels">{Array.from({ length: n }, (_, i) => <div key={i} className="skel" style={{ '--i': i }} />)}</div>

/* ---------- main ---------- */
export default function App() {
  const [lang, setL] = useState(() => ld('lang', /^it/i.test(navigator.language) ? 'it' : 'en'))
  setLang(lang)
  const [theme, setTheme] = useState(() => ld('theme', 'system'))
  const [sysDark, setSysDark] = useState(() => window.matchMedia?.('(prefers-color-scheme: dark)').matches)
  const dark = theme === 'dark' || (theme === 'system' && sysDark)
  const darkRef = useRef(dark); darkRef.current = dark
  const [tab, setTab] = useState('home')
  const [stack, setStack] = useState([])
  const [dir, setDir] = useState('fade')
  const [me, setMe] = useState(null)
  const [onboard, setOnboard] = useState(() => !ld('onboarded', false))
  const [nearby, setNearby] = useState({ stops: [], loading: true, error: null, updated: 0 })
  const [filter, setFilter] = useState('all')
  const [stTab, setStTab] = useState('near')
  const [favStops, setFavStops] = useState(() => ld('favStops', []))
  const [favs, setFavs] = useState(() => ld('favs', {}))
  const [pref, setPref] = useState(() => ld('pref', 'fast'))
  const [alerts, setAlerts] = useState([])
  const [strikeOff, setStrikeOff] = useState(false)
  const [plan, setPlan] = useState({ from: null, to: null, mode: 'now', value: '', res: null, loading: false, err: '' })
  const [snap, setSnap] = useState(1)
  const [H, setH] = useState(() => window.innerHeight)
  const [base, setBase] = useState(158)
  const [laid, setLaid] = useState(false)
  const sheetEl = useRef(null), probeEl = useRef(null)
  const [wide, setWide] = useState(window.innerWidth >= 900)
  const [toast, setToast] = useState('')
  const [tripLive, setTripLive] = useState(false)
  const [user, setUserState] = useState(() => ld('user', null))

  const appEl = useRef(null), mapEl = useRef(null), map = useRef(null), ready = useRef(false)
  const meRef = useRef(null), mk = useRef({}), sheetPx = useRef(0)
  const screen = stack[stack.length - 1] || { t: tab }

  const push = (s) => { setDir('fwd'); setStack((a) => [...a, s]) }
  const pop = () => { setDir('back'); setStack((a) => a.slice(0, -1)) }
  const goTab = (k) => { setDir('fade'); setStack([]); setTab(k); if (k === 'home' || k === 'nearby') setSnap((s) => Math.max(s, 1)) }
  const saveUser = (u) => { setUserState(u); sv('user', u) }
  const signOut = () => { saveUser(null); say(t('Signed out')) }
  const snapshot = () => ({ favs, favStops, pref, lang, theme })
  async function syncDown(u) {
    if (!SB || !u?.token) return
    try {
      const r = await sbFetch(`/rest/v1/user_data?select=data&user_id=eq.${u.id}`, { method: 'GET', token: u.token })
      const d = r[0]?.data; if (!d) return
      if (d.favs) { setFavs(d.favs); sv('favs', d.favs) } if (d.favStops) { setFavStops(d.favStops); sv('favStops', d.favStops) } if (d.pref) { setPref(d.pref); sv('pref', d.pref) }
    } catch { /* optional */ }
  }
  useEffect(() => { // cloud backup of favourites/settings (only when signed in with a cloud account)
    if (!SB || !user?.cloud) return
    const id = setTimeout(() => sbFetch('/rest/v1/user_data?on_conflict=user_id', { token: user.token, headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: { user_id: user.id, data: snapshot() } }).catch(() => {}), 1500)
    return () => clearTimeout(id)
  }, [favs, favStops, pref, user])
  const say = (m) => { setToast(m); setTimeout(() => setToast(''), 2400) }

  /* layout + theme */
  useLayoutEffect(() => {
    const r = () => { setH(appEl.current.clientHeight); setWide(window.innerWidth >= 900); setBase(parseFloat(getComputedStyle(probeEl.current).bottom) || 0) }
    r(); requestAnimationFrame(() => setLaid(true)); window.addEventListener('resize', r)
    const mq = window.matchMedia?.('(prefers-color-scheme: dark)'), f = (e) => setSysDark(e.matches)
    mq?.addEventListener?.('change', f)
    return () => { window.removeEventListener('resize', r); mq?.removeEventListener?.('change', f) }
  }, [])
  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; document.querySelector('meta[name=theme-color]')?.setAttribute('content', dark ? '#0B0F0D' : '#0B6B4F') }, [dark])
  const snaps = useMemo(() => { const a = H - base; return [Math.round(a * 0.34), Math.round(a * 0.6), a - 78] }, [H, base])
  const FULLS = ['home', 'lines', 'tickets', 'more', 'plan', 'place', 'signin', 'signup', 'profile']
  const full = !wide && FULLS.includes(screen.t)
  const fullRef = useRef(false); fullRef.current = full
  const sheetH = wide ? 0 : full ? H - base : snaps[snap]
  sheetPx.current = sheetH
  const baseRef = useRef(158), topEl = useRef(null); baseRef.current = base
  const flyVis = (ll, zoom) => {
    const m = map.current; if (!m) return
    const topH = (topEl.current?.offsetHeight || 0) + 6
    const off = wide ? [210, 0] : fullRef.current ? [0, 0] : [0, (topH - sheetPx.current - baseRef.current) / 2]
    m.flyTo({ center: ll, zoom, offset: off, duration: reduced() ? 0 : 900 })
  }
  const pad = () => { const top = (topEl.current?.offsetHeight || 70) + 18; return wide ? { top, bottom: 60, left: 450, right: 60 } : { top, bottom: sheetPx.current + baseRef.current + 28, left: 36, right: 36 } }

  /* map */
  const mapPos = useRef(CFG.CENTER)
  useEffect(() => {
    const m = new maplibregl.Map({ container: mapEl.current, style: STYLES[dark ? 'dark' : 'light'][0], center: [CFG.CENTER[1], CFG.CENTER[0]], zoom: 13.5, attributionControl: false })
    m.addControl(new maplibregl.AttributionControl({ compact: true, customAttribution: `<a href="https://transitous.org/sources" target="_blank" rel="noreferrer">Transitous</a>${contact ? ' · ' + contact : ''}` }), 'bottom-left')
    const fold = () => { const b = m.getContainer().querySelector('.maplibregl-ctrl-attrib'); b?.classList.remove('maplibregl-compact-show'); b?.removeAttribute('open') }
    m.on('load', fold); m.on('resize', fold); m.on('style.load', fold); setTimeout(fold, 400)
    map.current = m
    let fb = 0
    m.on('style.load', () => { clearTimeout(fb); addLayers(m, darkRef.current); ready.current = true; loadStopsLayer() })
    m.on('error', (e) => { if (!m.isStyleLoaded() && !fb && /style|Failed|fetch/i.test(String(e?.error?.message || ''))) fb = setTimeout(() => m.setStyle(STYLES[dark ? 'dark' : 'light'][1]), 0) })
    m.on('click', 'stops', (e) => { const p = e.features[0].properties; push({ t: 'stop', s: { stopId: p.id, parentId: p.id, name: p.name, lat: +p.lat, lon: +p.lon } }) })
    m.on('moveend', () => { const c = m.getCenter(); mapPos.current = [c.lat, c.lng]; clearTimeout(loadStopsLayer.tm); loadStopsLayer.tm = setTimeout(loadStopsLayer, 500) })
    return () => { ready.current = false; m.remove() }
  }, [])
  useEffect(() => { // theme change -> restyle
    const m = map.current; if (!m || !m.isStyleLoaded()) return
    ready.current = false; m.setStyle(STYLES[dark ? 'dark' : 'light'][0])
  }, [dark])
  useEffect(() => { map.current?.resize() }, [wide])

  /* my location */
  const locate = useCallback((fly = true) => new Promise((res) => {
    if (!navigator.geolocation) return res(null)
    navigator.geolocation.getCurrentPosition((p) => {
      const c = [p.coords.latitude, p.coords.longitude]; meRef.current = c; setMe(c)
      if (fly && map.current) flyVis([c[1], c[0]], 15.5)
      res(c)
    }, () => res(null), { enableHighAccuracy: true, timeout: 9000, maximumAge: 20000 })
  }), [])
  useEffect(() => {
    if (!me || !map.current) return
    mk.current.me?.remove()
    mk.current.me = marker(map.current, el('mk-me', '<i></i>'), me[0], me[1])
  }, [me])
  useEffect(() => { if (!onboard) locate(true).then((c) => loadNearby(c || undefined)) }, [onboard])

  /* nearby stops + departures */
  const nbReq = useRef(0)
  const loadNearby = useCallback(async (center, silent) => {
    center = center || meRef.current || mapPos.current
    const id = ++nbReq.current
    setNearby((n) => ({ ...n, loading: true, error: null, center }))
    const R = CFG.RADIUS, dLa = R / 111320, dLo = R / (111320 * Math.cos((center[0] * Math.PI) / 180))
    try {
      const raw = await get('/api/v1/map/stops', { min: `${center[0] - dLa},${center[1] - dLo}`, max: `${center[0] + dLa},${center[1] + dLo}` }, { ttl: 300 })
      const groups = new Map()
      for (const s of raw) {
        const d = hav(center, [s.lat, s.lon]); if (d > R) continue
        const key = s.parentId || nice(s.name).toLowerCase(), g = groups.get(key)
        if (!g) groups.set(key, { ...s, distance: d, key, modes: [...(s.modes || [])] })
        else { g.modes = [...new Set([...g.modes, ...(s.modes || [])])]; if (d < g.distance) Object.assign(g, { lat: s.lat, lon: s.lon, distance: d, stopId: s.stopId, name: s.name }) }
      }
      const all = [...groups.values()].map((g) => ({ ...g, cats: g.modes.length ? stopCats(g.modes) : guessCats(g.name) })).sort((a, b) => a.distance - b.distance)
      // keep the nearest few stops of EVERY transport type (bus, metro, train, tram, ferry), not just the closest ones
      const picked = new Map()
      for (const [cat, [n, max]] of Object.entries(CFG.PICK)) all.filter((g) => g.cats.includes(cat) && g.distance <= max).slice(0, n).forEach((g) => picked.set(g.key, g))
      if (!picked.size) all.slice(0, 8).forEach((g) => picked.set(g.key, g))
      const byDist = [...picked.values()].sort((a, b) => a.distance - b.distance).slice(0, 14)
      const firsts = ['bus', 'metro', 'train', 'tram', 'ferry', 'other'].map((c) => byDist.find((g) => g.cats.includes(c))).filter(Boolean)
      const list = [...new Set([...firsts, ...byDist])]
      const results = await Promise.all(list.map(async (s) => {
        const n = s.cats.length === 1 && s.cats[0] === 'bus' ? 14 : 30
        try { const r = await get('/api/v1/stoptimes', { stopId: s.parentId || s.stopId, n }, { ttl: 4 }); return { ...s, n, times: r.stopTimes || [] } } catch { return { ...s, n, times: null } }
      }))
      if (id !== nbReq.current) return
      if (results.length && results.every((r) => r.times === null)) throw new Error('all failed')
      const al = new Map()
      results.forEach((r) => (r.times || []).forEach((x) => (x.place?.alerts || []).forEach((a) => a.headerText && al.set(a.headerText, a))))
      setAlerts((old) => { const m = new Map(old.map((a) => [a.headerText, a])); al.forEach((v, k) => m.set(k, v)); return [...m.values()] })
      setNearby({ stops: results, loading: false, error: null, updated: Date.now(), center })
    } catch (e) { if (id === nbReq.current) setNearby((n) => ({ ...n, loading: false, error: e.message || 'error' })) }
  }, [])
  useEffect(() => { // auto refresh while visible
    const id = setInterval(() => document.visibilityState === 'visible' && !onboard && loadNearby(nearby.center, true), 60000)
    return () => clearInterval(id)
  }, [nearby.center, onboard, loadNearby])
  const nbRef = useRef(nearby); nbRef.current = nearby
  const scrRef = useRef(screen.t); scrRef.current = screen.t
  useEffect(() => { // quiet background refresh of the departures on screen (no visible timer)
    if (onboard) return
    const id = setInterval(async () => {
      if (document.visibilityState !== 'visible') return
      const k = scrRef.current, n = k === 'home' ? 3 : k === 'nearby' ? 8 : 0
      if (!n) return
      const res = await Promise.all(nbRef.current.stops.slice(0, n).map((s) => get('/api/v1/stoptimes', { stopId: s.parentId || s.stopId, n: s.n || 14 }, { ttl: 4 }).then((r) => r.stopTimes || null).catch(() => null)))
      setNearby((o) => ({ ...o, updated: Date.now(), stops: o.stops.map((s, i) => (i < n && res[i] ? { ...s, times: res[i] } : s)) }))
    }, CFG.REFRESH * 1000)
    return () => clearInterval(id)
  }, [onboard])

  const loadStopsLayer = useCallback(async () => {
    const m = map.current
    if (!m || !ready.current || fullRef.current || !m.getSource('stops')) return
    if (m.getZoom() < 14.5) { m.getSource('stops').setData(fc([])); return }
    const b = m.getBounds()
    try {
      const raw = await get('/api/v1/map/stops', { min: `${b.getSouth()},${b.getWest()}`, max: `${b.getNorth()},${b.getEast()}` }, { ttl: 120 })
      const seen = new Set(), feats = []
      for (const s of raw) { const id = s.parentId || s.stopId; if (seen.has(id) || feats.length > 300) continue; seen.add(id); feats.push({ type: 'Feature', properties: { id, name: nice(s.name), lat: s.lat, lon: s.lon, cat: s.modes?.length ? stopCat(s.modes) : guessCats(s.name)[0] }, geometry: { type: 'Point', coordinates: [s.lon, s.lat] } }) }
      m.getSource('stops').setData(fc(feats))
    } catch { /* keep */ }
  }, [])
  useEffect(() => { if (!full) { map.current?.resize(); loadStopsLayer(); if (screen.t === 'nearby' && meRef.current) flyVis([meRef.current[1], meRef.current[0]], 15.5) } }, [full, screen.t])

  /* sheet drag */
  const drag = useRef(null)
  const gDown = (e) => { drag.current = { y: e.clientY, h: snaps[snap], t: performance.now(), v: 0, ly: e.clientY, lt: performance.now() }; e.currentTarget.setPointerCapture(e.pointerId); appEl.current.classList.add('dragging') }
  const gMove = (e) => {
    const d = drag.current; if (!d) return
    const h = Math.max(snaps[0] - 30, Math.min(snaps[2] + 10, d.h + (d.y - e.clientY)))
    const now = performance.now(); d.v = (d.ly - e.clientY) / Math.max(1, now - d.lt); d.ly = e.clientY; d.lt = now
    appEl.current.style.setProperty('--sheet', h + 'px')
  }
  const gUp = () => {
    const d = drag.current; if (!d) return; drag.current = null
    const cur = parseFloat(appEl.current.style.getPropertyValue('--sheet')) || snaps[snap], proj = cur + d.v * 180
    let best = 0; snaps.forEach((s, i) => { if (Math.abs(s - proj) < Math.abs(snaps[best] - proj)) best = i })
    appEl.current.classList.remove('dragging'); appEl.current.style.setProperty('--sheet', snaps[best] + 'px'); setSnap(best)
  }

  /* strike / service banner */
  const strike = alerts.find((a) => a.cause === 'STRIKE' && a.impactPeriod?.[0]?.start && (new Date(a.impactPeriod[0].start) - Date.now()) < 36 * 3600e3 && (new Date(a.impactPeriod[0].end || a.impactPeriod[0].start) > Date.now()))

  /* shared actions */
  const openTrip = (x) => push({ t: 'trip', ref: { tripId: x.tripId, name: x.displayName || x.routeShortName || x.tripShortName, color: x.routeColor, mode: x.mode } })
  const toggleFav = (s) => { const k = s.parentId || s.stopId, on = favStops.some((f) => f.id === k), n = on ? favStops.filter((f) => f.id !== k) : [...favStops, { id: k, name: s.name, lat: s.lat, lon: s.lon }]; setFavStops(n); sv('favStops', n) }
  const isFav = (s) => favStops.some((f) => f.id === (s.parentId || s.stopId))
  const startPlan = (to) => { setPlan((p) => ({ ...p, to: to || p.to, res: null, err: '' })); push({ t: 'plan' }) }

  const legendCats = screen.t === 'trip' ? [modeCat(screen.ref.mode)] : screen.t === 'nearby' ? CATS.filter((c) => c !== 'all' && nearby.stops.some((x) => (x.times || []).some((y) => modeCat(y.mode) === c))) : []
  const strikeEl = strike && !strikeOff && (
    <div className="strike" role="alert"><I.warn /><a href="https://scioperi.mit.gov.it/mit2/public/scioperi" target="_blank" rel="noreferrer"><b>{t('Strike alert')}</b> {strike.headerText}</a><button onClick={() => setStrikeOff(true)} aria-label="Close"><I.close /></button></div>)
  const common = { push, pop, openTrip, map, say, pad, snap, setSnap, wide, flyVis }

  return (
    <div data-screen={screen.t} className={'device' + (laid ? ' laid' : '')} ref={appEl} style={{ '--sheet': sheetH + 'px' }} data-snap={snap} data-full={full}>
      <div ref={mapEl} className="map" role="region" aria-label="Map" />
      <div className="topbar" ref={topEl}>
        <div className="brandbar">
          <div className="logo"><i><I.nav /></i><span className="wm"><b>Go</b>Italia</span></div>
          <span className="spacer" />
          {nearby.error && <span className="badge-off">{t('Offline')}</span>}
        </div>
        {strikeEl}
        {legendCats.length > 0 && (
          <div className="legend">{screen.t === 'trip' && tripLive && <span><i className="d rt" />{t('Live position')}</span>}{legendCats.map((c) => { const Ic = I[c]; return <span key={c}><span className="lg" style={{ background: '#' + CAT_COLOR[c] }}><Ic /></span>{t(c[0].toUpperCase() + c.slice(1))}</span> })}</div>)}
      </div>
      <button className="fab" onClick={() => locate(true)} aria-label={t('My location')}><I.locate /></button>

      <i className="probe" ref={probeEl} />
      <section className="sheet" aria-label="Panel" ref={sheetEl}>
        <div className="grab" role="button" tabIndex={0} aria-label="Resize" onPointerDown={gDown} onPointerMove={gMove} onPointerUp={gUp} onPointerCancel={gUp} onKeyDown={(e) => e.key === 'Enter' && setSnap((snap + 1) % 3)}><span /></div>
        <div className="sheet-body" id="body">
          <div key={screen.t + (screen.ref?.tripId || screen.s?.stopId || screen.i || '')} className={'screen ' + dir}>
            {full && <div className="pagehead"><div className="logo"><i><I.nav /></i><span className="wm"><b>Go</b>Italia</span></div>{nearby.error && <span className="badge-off">{t('Offline')}</span>}</div>}
            {full && strikeEl}
            {screen.t === 'home' && <Home {...common} me={me} nearby={nearby} loadNearby={loadNearby} favs={favs} startPlan={startPlan} goTab={goTab} />}
            {screen.t === 'nearby' && <Nearby {...common} nearby={nearby} loadNearby={loadNearby} filter={filter} setFilter={setFilter} stTab={stTab} setStTab={setStTab} favStops={favStops} />}
            {screen.t === 'stop' && <StopView {...common} s={screen.s} nearby={nearby} fav={isFav(screen.s)} toggleFav={() => toggleFav(screen.s)} me={me} />}
            {screen.t === 'trip' && <TripView {...common} ref0={screen.ref} setTripLive={setTripLive} />}
            {screen.t === 'lines' && <Lines {...common} nearby={nearby} alerts={alerts} />}
            {screen.t === 'tickets' && <Tickets me={me} nearby={nearby} map={map} />}
            {screen.t === 'more' && <More lang={lang} setL={(v) => { setL(v); sv('lang', v) }} theme={theme} setTheme={(v) => { setTheme(v); sv('theme', v) }} pref={pref} setPref={(v) => { setPref(v); sv('pref', v) }} favs={favs} setFavs={(v) => { setFavs(v); sv('favs', v) }} favStops={favStops} setFavStops={(v) => { setFavStops(v); sv('favStops', v) }} push={push} user={user} signOut={signOut} say={say} />}
            {['signin', 'signup', 'profile'].includes(screen.t) && <Auth mode={screen.t} user={user} setUser={saveUser} pop={pop} push={push} onSignedIn={syncDown} />}
            {screen.t === 'plan' && <Plan {...common} plan={plan} setPlan={setPlan} me={me} favs={favs} pref={pref} setAlerts={setAlerts} />}
            {screen.t === 'detail' && <Detail {...common} plan={plan} i={screen.i} pref={pref} />}
            {screen.t === 'place' && <Plan {...common} plan={plan} setPlan={setPlan} me={me} favs={favs} pref={pref} setAlerts={setAlerts} pickFav={screen.k} setFavs={(v) => { setFavs(v); sv('favs', v) }} />}
          </div>
        </div>
      </section>

      <nav className="nav" aria-label="Main">
        {NAV.map(([k, ic, label]) => { const Ic = I[ic]; return <button key={k} aria-current={tab === k ? 'page' : undefined} onClick={() => goTab(k)}><i><Ic /></i>{t(label)}</button> })}
      </nav>
      {toast && <div className="toast" role="status">{toast}</div>}

      {onboard && (
        <div className="overlay"><div className="onb">
          <div className="logo big"><i><I.nav /></i></div>
          <h2>{t('Live buses, trams, metro and trains')}</h2>
          <p>{t('Allow location to see the stops and departures around you. It never leaves your device.')}</p>
          <button className="btn primary" onClick={() => { sv('onboarded', true); setOnboard(false) }}>{t('Use my location')}</button>
          <button className="btn tonal" onClick={() => { sv('onboarded', true); meRef.current = null; setOnboard(false) }}>{t('Not now, show Rome')}</button>
        </div></div>)}
    </div>
  )
}

/* ---------- screens ---------- */
function StopCard({ s, onOpen, openTrip, cat = 'all', max = 4, i = 0 }) {
  const groups = groupTimes(s.times, cat).slice(0, max), cats = new Set((s.times || []).map((x) => modeCat(x.mode)))
  const sc = s.cats?.length ? stopCat(s.modes || []) || s.cats[0] : [...cats][0] || 'bus'
  const lines = [...new Set((s.times || []).map((x) => lineName(x.displayName || x.routeShortName)))].slice(0, 7).join(', ')
  return (
    <div className="card stopcard" style={{ '--i': i }}>
      <button className="stophead" onClick={() => onOpen(s)}>
        <span className="sq" style={{ background: '#' + CAT_COLOR[sc] }}><StopIcon cat={sc} /></span>
        <span className="sn"><b>{nice(s.name)}</b><small>{[s.distance != null && `${t('{m} min walk', { m: walkMin(s.distance) })}`, lines].filter(Boolean).join(' · ')}</small></span>
        <I.chev />
      </button>
      {s.times === null ? <p className="muted pad">{t("Couldn't load this stop. Pull to refresh.")}</p>
        : groups.length ? groups.map((g, k) => <DepRow key={k} list={g} onOpen={openTrip} i={k} />) : <p className="muted pad">{t('No departures in the next hour.')}</p>}
    </div>
  )
}

function Home({ push, openTrip, nearby, loadNearby, startPlan, goTab, favs }) {
  const h = romeHour(), greet = h < 5 ? 'Good night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'
  const ORDER = ['bus', 'metro', 'train', 'tram', 'ferry']
  const byCat = ORDER.map((c) => [c, nearby.stops.find((s) => (s.cats || []).includes(c))]).filter(([, s]) => s)
  const top = [...new Map([...byCat.map(([, s]) => s), ...nearby.stops].map((s) => [s.key, s])).values()].slice(0, 4)
  return (
    <>
      <h1 className="greet">{t(greet)}</h1>
      <button className="search" onClick={() => startPlan()}><span className="si"><I.search /></span>{t('Where to?')}</button>
      <div className="quick">
        {['home', 'work'].map((k) => <button key={k} className="qk" onClick={() => (favs[k] ? startPlan(favs[k]) : push({ t: 'place', k }))}><b>{t(k === 'home' ? 'Home' : 'Work')}</b><small>{favs[k] ? nice(favs[k].name) : t('Tap to set')}</small></button>)}
      </div>
      {byCat.length > 0 && (<>
        <h2>{t('Around you')}</h2>
        <div className="tiles">{byCat.map(([c, s], i) => {
          const g = groupTimes(s.times, c)[0], Ic = I[c], m = g ? minutesUntil(g.at(0).place.departure || g.at(0).place.arrival) : null
          return (
            <button key={c} className="tile" style={{ '--c': '#' + CAT_COLOR[c], '--i': i }} onClick={() => push({ t: 'stop', s })}>
              <span className="tile-ic"><Ic /></span>
              <b>{t(c[0].toUpperCase() + c.slice(1))}</b>
              <span className="tile-n">{nice(s.name)}</span>
              <small>{t('{m} min walk', { m: walkMin(s.distance) })}{g && m != null && m < 60 ? ` · ${lineName(g[0].displayName || g[0].routeShortName)} ${Math.max(0, m)}′` : ''}</small>
            </button>)
        })}</div>
      </>)}
      <h2>{t('Nearest stops')}</h2>
      {nearby.loading && !nearby.stops.length && <Skel />}
      {nearby.error && !nearby.stops.length && <div className="err"><b>{t("Couldn't load live data.")}</b><button className="btn tonal" onClick={() => loadNearby()}>{t('Retry')}</button></div>}
      {!nearby.loading && !nearby.error && !nearby.stops.length && <p className="muted">{t('No stops found nearby. Move the map to a city and tap refresh.')}</p>}
      <div className="stagger">{top.map((s, i) => <StopCard key={s.key} s={s} i={i} max={3} openTrip={openTrip} onOpen={(x) => push({ t: 'stop', s: x })} />)}</div>
      {nearby.stops.length > top.length && <button className="btn tonal wide" onClick={() => goTab('nearby')}>{t('All stops nearby')} <I.chev /></button>}
    </>
  )
}

function Nearby({ push, openTrip, nearby, loadNearby, filter, setFilter, stTab, setStTab, favStops }) {
  const cats = new Set(nearby.stops.flatMap((s) => [...(s.cats || []), ...(s.times || []).map((x) => modeCat(x.mode))]))
  const list = filter === 'all' ? nearby.stops : nearby.stops.filter((s) => (s.cats || []).includes(filter) || groupTimes(s.times, filter).length)
  return (
    <>
      <div className="tabs2"><button aria-pressed={stTab === 'near'} onClick={() => setStTab('near')}>{t('Nearest stops')}</button><button aria-pressed={stTab === 'fav'} onClick={() => setStTab('fav')}>★ {t('Favourites')}</button></div>
      {stTab === 'near' ? (<>
        <div className="row between"><Modes cats={cats} value={filter} onChange={setFilter} /><button className="icbtn" onClick={() => loadNearby()} aria-label="Refresh"><I.refresh /></button></div>
        {nearby.loading && !nearby.stops.length && <Skel n={4} />}
        <div className="stagger">{list.map((s, i) => <StopCard key={s.key} s={s} i={i} cat={filter} openTrip={openTrip} onOpen={(x) => push({ t: 'stop', s: x })} />)}</div>
      </>) : favStops.length ? favStops.map((f) => (
        <button key={f.id} className="card stophead solo" onClick={() => push({ t: 'stop', s: { stopId: f.id, parentId: f.id, name: f.name, lat: f.lat, lon: f.lon } })}><span className="sq"><StopIcon cat="bus" /></span><span className="sn"><b>{nice(f.name)}</b></span><I.chev /></button>
      )) : <p className="muted">{t('No favourite stops yet. Tap the star on a stop to add it.')}</p>}
    </>
  )
}

function StopView({ s, pop, openTrip, map, nearby, fav, toggleFav, me, snap, setSnap, flyVis }) {
  const [times, setTimes] = useState(() => nearby.stops.find((x) => (x.parentId || x.stopId) === (s.parentId || s.stopId))?.times || null)
  const [f, setF] = useState('all'), [upd, setUpd] = useState(0), [busy, setBusy] = useState(false)
  const load = useCallback(async () => { setBusy(true); try { const r = await get('/api/v1/stoptimes', { stopId: s.parentId || s.stopId, n: 30 }, { ttl: 20 }); setTimes(r.stopTimes || []); setUpd(Date.now()) } catch { setTimes((x) => x || []) } setBusy(false) }, [s])
  useEffect(() => { load(); const id = setInterval(load, CFG.REFRESH * 1000); const m = map.current; flyVis([s.lon, s.lat], 16.2); const mkr = marker(m, el('mk-stop', '<i></i>'), s.lat, s.lon); return () => { clearInterval(id); mkr.remove() } }, [s])
  useEffect(() => { const id = setInterval(() => setUpd((u) => u), 15000); return () => clearInterval(id) }, [])
  const cats = new Set((times || []).map((x) => modeCat(x.mode))), groups = groupTimes(times, f)
  const d = me ? hav(me, [s.lat, s.lon]) : null
  return (
    <>
      <div className="head"><button className="back" onClick={pop}><I.back />{t('Back')}</button><button className={'icbtn star' + (fav ? ' on' : '')} onClick={toggleFav} aria-label={t(fav ? 'Remove from favourites' : 'Add to favourites')}><I.star on={fav} /></button></div>
      <h1 className="title">{nice(s.name)}</h1>
      <p className="muted">{d != null && t('{m} min walk', { m: walkMin(d) })}</p>
      <div className="row between"><Modes cats={cats} value={f} onChange={setF} /></div>
      {times === null && <Skel />}
      <div className="card stagger">{groups.map((g, i) => <DepRow key={i} i={i} list={g} onOpen={openTrip} />)}{times && !groups.length && <p className="muted pad">{t('No departures in the next hour.')}</p>}</div>
    </>
  )
}

function TripView({ ref0, pop, map, pad, setTripLive, say }) {
  const [d, setD] = useState(null), [err, setErr] = useState(false), [, tick] = useState(0)
  useEffect(() => { setTripLive(!!d?.l.realTime); return () => setTripLive(false) }, [d])
  const mkRef = useRef(null), tween = useRef(null), vn = useRef(null)
  const col = '#' + lineColor(ref0.color, ref0.mode), cat = modeCat(ref0.mode)
  const load = useCallback(async () => {
    try {
      const r = await get('/api/v5/trip', { tripId: ref0.tripId }, { ttl: 4 })
      const l = r.legs.find((x) => x.mode !== 'WALK') || r.legs[0]
      const stops = [l.from, ...(l.intermediateStops || []), l.to], g = l.legGeometry
      const pts = g?.points ? decode(g.points, g.precision || 6) : stops.map((s) => [s.lat, s.lon])
      setD({ l, stops, pts }); setErr(false)
    } catch { setErr(true) }
  }, [ref0.tripId])
  useEffect(() => { load(); const a = setInterval(load, 5000), b = setInterval(() => tick((n) => n + 1), 1000); return () => { clearInterval(a); clearInterval(b) } }, [load])

  const T = (s) => +new Date(s.departure || s.arrival || s.scheduledDeparture || s.scheduledArrival)
  const now = Date.now()
  const nextIdx = d ? (() => { const i = d.stops.findIndex((s) => T(s) > now); return i < 0 ? d.stops.length : i })() : 0

  // position: real segment if present, else delay-aware interpolation along the route shape
  const pos = useMemo(() => {
    if (!d) return null
    const B = (a, b) => bearing(a.lat, a.lon, b.lat, b.lon), S = d.stops
    if (nextIdx <= 0) return { la: S[0].lat, lo: S[0].lon, br: B(S[0], S[1] || S[0]) }
    if (nextIdx >= S.length) { const s = S.at(-1); return { la: s.lat, lo: s.lon, br: B(S.at(-2) || s, s) } }
    const a = d.stops[nextIdx - 1], b = d.stops[nextIdx], ta = +new Date(a.departure || a.scheduledDeparture || a.arrival), tb = T(b), f = tb > ta ? Math.max(0, Math.min(1, (now - ta) / (tb - ta))) : 0
    return { la: a.lat + (b.lat - a.lat) * f, lo: a.lon + (b.lon - a.lon) * f, br: bearing(a.lat, a.lon, b.lat, b.lon) }
  }, [d, nextIdx, Math.floor(now / 1000)])

  // map: route, stop dots, bus marker with smooth tween
  useEffect(() => {
    const m = map.current; if (!d) return
    showRoute(m, [{ type: 'Feature', properties: { color: col }, geometry: { type: 'LineString', coordinates: d.pts.map(([a, b]) => [b, a]) } }], true)
    const dots = d.stops.map((s) => { const n = el('mk-dot', '<i></i>'); n.style.setProperty('--c', col); n.title = nice(s.name); return marker(m, n, s.lat, s.lon) })
    fitPts(m, d.pts, pad())
    return () => { dots.forEach((x) => x.remove()); mkRef.current?.remove(); mkRef.current = null; clearRoute(m); cancelAnimationFrame(tween.current) }
  }, [!!d])
  useEffect(() => {
    const m = map.current; if (!d || !pos) return
    if (!mkRef.current) { vn.current = vehEl(lineName(ref0.name), lineColor(ref0.color, ref0.mode), true); vn.current.rot(pos.br); mkRef.current = marker(m, vn.current.el, pos.la, pos.lo); return }
    vn.current?.rot(pos.br)
    const from = mkRef.current.getLngLat(), to = [pos.lo, pos.la], t0 = performance.now()
    cancelAnimationFrame(tween.current)
    const step = (n) => { const p = Math.min(1, (n - t0) / 900); mkRef.current?.setLngLat([from.lng + (to[0] - from.lng) * p, from.lat + (to[1] - from.lat) * p]); if (p < 1) tween.current = requestAnimationFrame(step) }
    tween.current = requestAnimationFrame(step)
  }, [pos?.la, pos?.lo])

  if (err) return <><div className="head"><button className="back" onClick={pop}><I.back />{t('Back')}</button></div><div className="err"><b>{t("Couldn't load this trip.")}</b><button className="btn tonal" onClick={load}>{t('Retry')}</button></div></>
  const l = d?.l
  return (
    <>
      <div className="head"><button className="back" onClick={pop}><I.back />{t('Back')}</button></div>
      <div className="trip-head"><Chip name={ref0.name} color={ref0.color} mode={ref0.mode} />
        {d ? <div className="od"><div className="route-od"><span>{nice(d.stops[0].name)}</span><I.arrow /><span>{nice(l.headsign || l.to.name)}</span></div>
          <small>{[l.agencyName && nice(l.agencyName), t('{n} stops', { n: d.stops.length })].filter(Boolean).join(' · ')} · {l.realTime ? <span className="tag">{t('Live')}</span> : t('Scheduled')}</small></div> : <div className="skel grow" />}</div>
      {!d ? <Skel n={5} /> : (<>
        <div className="tl stagger">{d.stops.map((s, k) => {
          const tm = s.arrival && k ? s.arrival : s.departure || s.arrival, sch = k ? s.scheduledArrival || s.scheduledDeparture : s.scheduledDeparture || s.scheduledArrival
          const shifted = l.realTime && tm && sch && Math.abs(new Date(tm) - new Date(sch)) >= 60000, passed = k < nextIdx, isNext = k === nextIdx, last = k === d.stops.length - 1
          return (
            <div key={k} className={'tl-row' + (passed ? ' passed' : '')} style={{ '--i': Math.min(k, 12) }}>
              <div className="tl-time">{tm ? fmtTime(tm) : ''}{shifted && <s>{fmtTime(sch)}</s>}</div>
              <div className={'tl-rail' + (k === 0 ? ' first' : '') + (last ? ' last' : '')} style={{ '--c': col }}>
                {isNext && nextIdx > 0 && !last && <span className="busmark" style={{ '--c': col }}><Glyph k={cat} /></span>}<span className={'node' + (isNext ? ' nextnode' : '')} />
              </div>
              <div className="tl-body"><div className="stn" style={{ fontWeight: isNext || last ? 800 : 600 }}>{nice(s.name)}{last && <span className="destflag">{t('Destination')}</span>}</div>
                {(s.track || isNext) && <div className="info">{s.track && <span className="plat">{t('Platform')} {s.track}</span>}{isNext && <span className="muted small">{minutesUntil(tm) <= 0 ? t('Arriving') : t('in {m} min', { m: minutesUntil(tm) })}</span>}{isNext && <Delay sched={sch} actual={tm} rt={l.realTime} cancelled={s.cancelled} />}</div>}
              </div>
            </div>)
        })}</div>
        <p className="small muted note">{l.realTime ? t('Position estimated from real-time delay.') : t('Position estimated from the timetable.')}</p>
      </>)}
    </>
  )
}

function Lines({ push, nearby, alerts, openTrip }) {
  const [q, setQ] = useState(''), [cat, setCat] = useState('all'), [mode, setMode] = useState('lines')
  const items = useMemo(() => {
    const m = new Map()
    nearby.stops.forEach((s) => (s.times || []).forEach((x) => { const n = lineName(x.displayName || x.routeShortName), k = n + '|' + modeCat(x.mode); if (n && !m.has(k)) m.set(k, { name: n, mode: x.mode, cat: modeCat(x.mode), color: x.routeColor, tripId: x.tripId, head: nice(x.headsign || ''), live: false, at: nice(s.name) }) }))
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }))
  }, [nearby.updated])
  const shown = items.filter((l) => (cat === 'all' || l.cat === cat) && l.name.toLowerCase().includes(q.toLowerCase()))
  return (
    <>
      <div className="searchbox"><I.search /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Search for a line')} inputMode="search" /></div>
      <div className="tabs2"><button aria-pressed={mode === 'lines'} onClick={() => setMode('lines')}>{t('Lines')}</button><button aria-pressed={mode === 'alerts'} onClick={() => setMode('alerts')}>{t('Alerts')}{alerts.length ? ` (${alerts.length})` : ''}</button></div>
      {mode === 'lines' ? (<>
        <Modes cats={new Set(items.map((l) => l.cat))} value={cat} onChange={setCat} />
        <p className="small muted">{t('Lines serving stops near you.')}</p>
        {!items.length && <Skel n={4} />}
        <div className="card stagger">{shown.map((l, i) => (
          <button key={l.name + l.cat} className="dep line" style={{ '--i': Math.min(i, 14) }} disabled={!l.tripId} onClick={() => openTrip({ tripId: l.tripId, routeShortName: l.name, routeColor: l.color, mode: l.mode })}>
            <Chip name={l.name} color={l.color} mode={l.mode} /><div className="hd">{l.head || t(l.cat[0].toUpperCase() + l.cat.slice(1))}<small>{l.at || t('Live on the map')}</small></div><I.chev />
          </button>))}{items.length > 0 && !shown.length && <p className="muted pad">{t('No lines match your search.')}</p>}</div>
      </>) : alerts.length ? alerts.map((a, i) => <div key={i} className="card alert"><b>{a.headerText}</b>{a.descriptionText && <p>{a.descriptionText.slice(0, 280)}</p>}</div>) : <p className="muted">{t('No service alerts reported right now.')}</p>}
    </>
  )
}

function Tickets({ me, nearby, map }) {
  const c0 = nearestCity((me || nearby.center || [41.9, 12.49])[0], (me || nearby.center || [41.9, 12.49])[1], CITIES), [sel, setSel] = useState(c0.n)
  const c = CITIES.find((x) => x.n === sel)
  const rail = [['Trenitalia', 'https://www.trenitalia.com'], ['Italo', 'https://www.italotreno.it']]
  return (
    <>
      <h1 className="title">{t('Tickets')}</h1>
      <p className="muted">{t('Buy tickets from the official operators. Prices and rules change, so always check there.')}</p>
      <h2>{t('City')}</h2>
      <div className="chips">{CITIES.map((x) => <button key={x.n} className="chp" aria-pressed={sel === x.n} onClick={() => { setSel(x.n); map.current.flyTo({ center: [x.lon, x.lat], zoom: 12.5 }) }}>{t(x.n)}</button>)}</div>
      <div className="card stagger">{[...c.ops, ...rail.filter((r) => !c.ops.some((o) => o[0] === r[0]))].map(([n, u], i) => (
        <a key={n} className="dep line" style={{ '--i': i }} href={u} target="_blank" rel="noreferrer"><span className="sq"><I.ticket /></span><div className="hd">{n}<small>{t('Official site')}</small></div><I.ext /></a>))}</div>
    </>
  )
}

function Seg({ value, opts, onChange }) { return <div className="seg">{opts.map(([v, l]) => <button key={v} aria-pressed={value === v} onClick={() => onChange(v)}>{l}</button>)}</div> }
const SB = window.APP_CONFIG?.supabaseUrl && window.APP_CONFIG?.supabaseKey ? { url: window.APP_CONFIG.supabaseUrl.replace(/\/$/, ''), key: window.APP_CONFIG.supabaseKey } : null
async function sbFetch(path, { body, token, method = 'POST', headers = {} } = {}) {
  const res = await fetch(SB.url + path, { method, headers: { apikey: SB.key, 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined })
  const j = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(j.msg || j.error_description || j.message || 'HTTP ' + res.status)
  return j
}
const initials = (n = '') => n.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || '?'

function Auth({ mode, user, setUser, pop, push, onSignedIn }) {
  const [f, setF] = useState({ name: user?.name || '', email: user?.email || '', password: '' }), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false)
  const up = (k) => (e) => setF({ ...f, [k]: e.target.value })
  async function submit(e) {
    e.preventDefault(); setMsg(''); setBusy(true)
    try {
      if (mode === 'profile') { setUser({ ...user, name: f.name.trim() || user.name, email: f.email.trim() }); pop(); return }
      if (!SB) { if (!f.name.trim()) throw new Error(t('Please enter your name.')); setUser({ name: f.name.trim(), email: f.email.trim(), local: true }); pop(); return }
      if (f.password.length < 8) throw new Error(t('Password must be at least 8 characters.'))
      const j = mode === 'signup' ? await sbFetch('/auth/v1/signup', { body: { email: f.email.trim(), password: f.password, data: { name: f.name.trim() } } }) : await sbFetch('/auth/v1/token?grant_type=password', { body: { email: f.email.trim(), password: f.password } })
      if (!j.access_token) { setMsg(t('Check your email to confirm your account, then sign in.')); return }
      const u = { id: j.user.id, email: j.user.email, name: j.user.user_metadata?.name || f.name.trim() || j.user.email.split('@')[0], token: j.access_token, cloud: true }
      setUser(u); onSignedIn?.(u); pop()
    } catch (er) { setMsg(er.message) }
    setBusy(false)
  }
  const title = mode === 'profile' ? t('Edit profile') : mode === 'signup' ? t('Create account') : t('Sign in')
  return (
    <>
      <div className="head"><button className="back" onClick={pop}><I.back />{t('Back')}</button></div>
      <h1 className="title">{title}</h1>
      {!SB && mode !== 'profile' && <p className="muted small">{t('Cloud sign-in is not configured on this site yet, so your profile is saved on this device only.')}</p>}
      <form className="form" onSubmit={submit}>
        {(mode !== 'signin' || (!SB)) && <label><span>{t('Name')}</span><input value={f.name} onChange={up('name')} autoComplete="name" /></label>}
        {(SB || mode === 'profile' || true) && <label><span>{t('Email')}{!SB && ` (${t('optional')})`}</span><input type="email" value={f.email} onChange={up('email')} autoComplete="email" required={!!SB && mode !== 'profile'} /></label>}
        {SB && mode !== 'profile' && <label><span>{t('Password')}</span><input type="password" value={f.password} onChange={up('password')} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} required /></label>}
        {msg && <p className="error" role="alert">{msg}</p>}
        <button className="btn primary wide" disabled={busy}>{busy ? '…' : mode === 'profile' ? t('Save') : !SB ? t('Create profile') : title}</button>
      </form>
      {mode !== 'profile' && SB && <button className="link center" onClick={() => { pop(); push({ t: mode === 'signup' ? 'signin' : 'signup' }) }}>{mode === 'signup' ? t('Already have an account? Sign in') : t('New here? Create an account')}</button>}
    </>
  )
}

function More({ lang, setL, theme, setTheme, pref, setPref, favs, setFavs, favStops, setFavStops, push, user, signOut, say }) {
  const share = async () => { const d = { title: 'GoItalia', url: location.href.split('#')[0] }; try { navigator.share ? await navigator.share(d) : (await navigator.clipboard.writeText(d.url), say(t('Link copied'))) } catch {} }
  const clearAll = () => { if (confirm(t('Delete all saved data on this device?'))) { try { localStorage.clear() } catch {} location.reload() } }
  return (
    <>
      <h1 className="title">{t('More')}</h1>
      {user ? (
        <div className="pcard"><span className="avatar">{initials(user.name)}</span><div className="pc-t"><b>{user.name}</b><small>{user.email || (user.local ? t('Profile on this device') : '')}</small></div>
          <button className="link" onClick={() => push({ t: 'profile' })}>{t('Edit')}</button></div>
      ) : (
        <div className="pcard solo"><span className="avatar"><I.user /></span><div className="pc-t"><b>{t('Your profile')}</b><small>{t('Save places and settings, and sync them across devices.')}</small></div>
          <div className="pc-btns"><button className="btn primary" onClick={() => push({ t: 'signin' })}>{t('Sign in')}</button><button className="btn tonal" onClick={() => push({ t: 'signup' })}>{t('Sign up')}</button></div></div>
      )}
      <h2>{t('Language')}</h2><Seg value={lang} onChange={setL} opts={[['en', 'English'], ['it', 'Italiano']]} />
      <h2>{t('Appearance')}</h2><Seg value={theme} onChange={setTheme} opts={[['system', t('System')], ['light', t('Light')], ['dark', t('Dark')]]} />
      <h2>{t('Route preference')}</h2><Seg value={pref} onChange={setPref} opts={[['fast', t('Fastest')], ['fewest', t('Fewest changes')], ['walk', t('Least walking')]]} />
      <h2>{t('Saved places')}</h2>
      <div className="card">{['home', 'work'].map((k) => (
        <div key={k} className="dep line static"><div className="hd">{t(k === 'home' ? 'Home' : 'Work')}<small>{favs[k] ? nice(favs[k].name) : t('Not set')}</small></div>
          <button className="link" onClick={() => push({ t: 'place', k })}>{favs[k] ? t('Change') : t('Set')}</button>{favs[k] && <button className="link" onClick={() => { const f = { ...favs }; delete f[k]; setFavs(f) }}>{t('Remove')}</button>}</div>))}</div>
      <h2>{t('Favourite stops')}</h2>
      <div className="card">{favStops.length ? favStops.map((f) => (
        <div key={f.id} className="dep line static"><span className="sq"><StopIcon cat="bus" /></span><div className="hd">{nice(f.name)}</div><button className="link" onClick={() => setFavStops(favStops.filter((x) => x.id !== f.id))}>{t('Remove')}</button></div>
      )) : <p className="muted pad">{t('No favourite stops yet. Tap the star on a stop to add it.')}</p>}</div>
      <h2>{t('App')}</h2>
      <div className="card">
        <button className="dep line" onClick={share}><div className="hd">{t('Share the app')}</div><I.chev /></button>
        {contact.includes('@') && <a className="dep line" href={`mailto:${contact}?subject=GoItalia%20feedback`}><div className="hd">{t('Send feedback')}</div><I.chev /></a>}
        <button className="dep line" onClick={clearAll}><div className="hd">{t('Delete saved data')}<small>{t('Favourites, places, settings and profile on this device')}</small></div><I.chev /></button>
        {user && <button className="dep line" onClick={signOut}><div className="hd">{t('Sign out')}</div><I.chev /></button>}
      </div>
      <p className="copy">Copyright by ITGo</p>
    </>
  )
}

function Plan({ plan, setPlan, me, favs, pref, push, pop, map, pad, setAlerts, pickFav, setFavs }) {
  const [field, setField] = useState(plan.to ? 'from' : 'to'), [q, setQ] = useState(''), [opts, setOpts] = useState([])
  const set = (o) => setPlan((p) => ({ ...p, ...o }))
  useEffect(() => { if (q.length < 2) { setOpts([]); return } const id = setTimeout(async () => { const c = map.current.getCenter(); try { setOpts((await get('/api/v1/geocode', { text: q, place: `${c.lat},${c.lng}`, language: 'it' }, { ttl: 120 })).slice(0, 6)) } catch { setOpts([]) } }, 280); return () => clearTimeout(id) }, [q])
  const pick = (o) => {
    const p = { name: nice(o.name), lat: o.lat, lon: o.lon }
    if (pickFav) { setFavs({ ...favs, [pickFav]: p }); pop(); return }
    set({ [field]: p }); setQ(''); setOpts([]); if (field === 'to' && !plan.from) setField('from')
  }
  const from = plan.from || (me ? { name: t('My location'), lat: me[0], lon: me[1] } : null)
  async function run() {
    if (!from || !plan.to) return
    set({ loading: true, err: '', res: null })
    const when = plan.mode === 'now' || !plan.value ? null : new Date(plan.value)
    try {
      const r = await get('/api/v5/plan', { fromPlace: `${from.lat},${from.lon}`, toPlace: `${plan.to.lat},${plan.to.lon}`, time: when?.toISOString(), arriveBy: plan.mode === 'arrive' && when ? 'true' : null, numItineraries: 6 }, { ttl: 60 })
      let its = r.itineraries || []
      const al = []; its.forEach((it) => it.legs.forEach((l) => (l.alerts || []).forEach((a) => a.headerText && al.push(a)))); if (al.length) setAlerts((o) => [...o, ...al.filter((a) => !o.some((b) => b.headerText === a.headerText))])
      const walk = (x) => x.legs.filter((l) => l.mode === 'WALK').reduce((n, l) => n + l.duration, 0)
      its = pref === 'fewest' ? [...its].sort((a, b) => a.transfers - b.transfers || a.duration - b.duration) : pref === 'walk' ? [...its].sort((a, b) => walk(a) - walk(b) || a.duration - b.duration) : its
      set({ loading: false, res: its, err: its.length ? '' : t('No route found. Check that both points are in a covered city.') })
    } catch (e) { set({ loading: false, err: t("Couldn't plan this trip right now. Try again.") }) }
  }
  const mins = (s) => Math.max(1, Math.round(s / 60))
  return (
    <>
      <div className="head"><button className="back" onClick={pop}><I.back />{t('Back')}</button></div>
      <h1 className="title">{pickFav ? t('Set ' + (pickFav === 'home' ? 'Home' : 'Work')) : t('Plan a trip')}</h1>
      {pickFav ? <div className="searchbox"><I.search /><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Search address or stop')} /></div> : (<>
        <div className="od-box">
          <button className={'odf' + (field === 'from' ? ' on' : '')} onClick={() => setField('from')}><small>{t('From')}</small>{from?.name || t('Choose a start')}</button>
          <button className="icbtn" onClick={() => set({ from: plan.to, to: from })} aria-label={t('Swap')}><I.swap /></button>
          <button className={'odf' + (field === 'to' ? ' on' : '')} onClick={() => setField('to')}><small>{t('To')}</small>{plan.to?.name || t('Where to?')}</button>
        </div>
        <div className="searchbox"><I.search /><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={field === 'from' ? t('Search a starting point') : t('Search address or stop')} /></div>
      </>)}
      {field === 'from' && !pickFav && <button className="opt" onClick={() => set({ from: null })}><I.locate /><b>{t('My location')}</b></button>}
      {!q && !pickFav && ['home', 'work'].filter((k) => favs[k]).map((k) => <button key={k} className="opt" onClick={() => set({ [field]: favs[k] })}><I.star /><span><b>{t(k === 'home' ? 'Home' : 'Work')}</b><small>{nice(favs[k].name)}</small></span></button>)}
      <div className="stagger">{opts.map((o, i) => <button key={i} className="opt" style={{ '--i': i }} onClick={() => pick(o)}>{(I[o.type === 'STOP' ? 'bus' : 'loc'])()}<span><b>{nice(o.name)}</b><small>{o.type === 'STOP' ? t('Stop') : o.type === 'ADDRESS' ? t('Address') : t('Place')}{o.areas?.[0]?.name ? ` · ${o.areas.find((a) => a.default)?.name || o.areas[0].name}` : ''}</small></span></button>)}</div>
      {!pickFav && (<>
        <Seg value={plan.mode} onChange={(v) => set({ mode: v })} opts={[['now', t('Leave now')], ['depart', t('Depart at')], ['arrive', t('Arrive by')]]} />
        {plan.mode !== 'now' && <input type="datetime-local" className="dt" value={plan.value} onChange={(e) => set({ value: e.target.value })} />}
        <button className="btn primary wide" disabled={!from || !plan.to || plan.loading} onClick={run}>{plan.loading ? t('Searching…') : t('Find routes')}</button>
        {plan.loading && <Skel n={3} />}
        {plan.err && <p className="error">{plan.err}</p>}
        <div className="stagger">{plan.res?.map((x, i) => (
          <button key={i} className={'card trip' + (i === 0 ? ' best' : '')} style={{ '--i': i }} onClick={() => push({ t: 'detail', i })}>
            <div className="trip-top"><strong>{mins(x.duration)} {t('min')}</strong><span className="muted">{fmtTime(x.startTime)} → {fmtTime(x.endTime)}</span></div>
            <div className="legs">{x.legs.filter((l) => l.mode !== 'WALK' || l.duration >= 120).map((l, j) => (
              <span key={j} className="leg">{j > 0 && <I.chev />}{l.mode === 'WALK' ? <span className="walk"><I.walk />{mins(l.duration ?? (new Date(l.endTime) - new Date(l.startTime)) / 1000)}</span> : <Chip name={l.displayName || l.routeShortName || l.tripShortName} color={l.routeColor} mode={l.mode} />}</span>))}</div>
            <small className="muted">{x.transfers === 0 ? t('Direct') : t('{n} changes', { n: x.transfers })}{i === 0 ? ` · ${t('Best route')}` : ''}</small>
          </button>))}</div>
      </>)}
    </>
  )
}

function Detail({ plan, i, pop, map, pad }) {
  const it = plan.res?.[i]
  useEffect(() => {
    const m = map.current; if (!it) return
    const feats = [], pts = []
    it.legs.forEach((l) => { const g = l.legGeometry, p = g?.points ? decode(g.points, g.precision || 6) : [[l.from.lat, l.from.lon], [l.to.lat, l.to.lon]]; pts.push(...p); feats.push({ type: 'Feature', properties: { walk: l.mode === 'WALK', color: '#' + lineColor(l.routeColor, l.mode) }, geometry: { type: 'LineString', coordinates: p.map(([a, b]) => [b, a]) } }) })
    showRoute(m, feats, true); fitPts(m, pts, pad())
    const a = marker(m, el('mk-end', ''), it.legs[0].from.lat, it.legs[0].from.lon), b = marker(m, el('mk-end to', ''), it.legs.at(-1).to.lat, it.legs.at(-1).to.lon)
    return () => { a.remove(); b.remove(); clearRoute(m) }
  }, [it])
  if (!it) return <button className="back" onClick={pop}><I.back />{t('Back')}</button>
  const mins = (s) => (Number.isFinite(s) ? Math.max(1, Math.round(s / 60)) : '–')
  const dur = (l) => l.duration ?? (new Date(l.endTime) - new Date(l.startTime)) / 1000
  return (
    <>
      <div className="head"><button className="back" onClick={pop}><I.back />{t('Back')}</button></div>
      <h1 className="title">{mins(it.duration)} {t('min')} <small className="muted">{fmtTime(it.startTime)} → {fmtTime(it.endTime)}</small></h1>
      <ol className="steps stagger">{it.legs.map((l, k) => {
        const walk = l.mode === 'WALK', c = '#' + lineColor(l.routeColor, l.mode), late = Math.round((new Date(l.startTime) - new Date(l.scheduledStartTime || l.startTime)) / 60000)
        return walk ? (
          <li key={k} className="step" style={{ '--c': '#8E9B94', '--i': k }}><b><I.walk />{t('Walk')} {mins(dur(l))} {t('min')}</b><small>{Math.round(l.distance || 0)} m · {nice(l.to.name)}</small></li>
        ) : (
          <li key={k} className="step" style={{ '--c': c, '--i': k }}>
            <div><b>{fmtTime(l.startTime)}</b> {t('Board')} <Chip sm name={l.displayName || l.routeShortName} color={l.routeColor} mode={l.mode} /> {t('at')} {nice(l.from.name)} {l.from.track && <span className="plat">{t('Platform')} {l.from.track}</span>} {l.realTime && late >= 1 && <span className="delay late">+{late} {t('min')}</span>}{l.realTime && late < 1 && <span className="delay ok">{t('On time')}</span>}</div>
            <small>{l.headsign ? `${t('Towards')} ${nice(l.headsign)} · ` : ''}{t('{n} stops', { n: (l.intermediateStops?.length || 0) + 1 })} · {mins(dur(l))} {t('min')}</small>
            <div><b>{fmtTime(l.endTime)}</b> {t('Get off at')} {nice(l.to.name)}</div>
          </li>)
      })}</ol>
    </>
  )
}
