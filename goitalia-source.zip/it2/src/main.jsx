import React from 'react'
import { createRoot } from 'react-dom/client'
import 'maplibre-gl/dist/maplibre-gl.css'
import './styles.css'
import App from './App.jsx'

class Boundary extends React.Component {
  state = { e: null }
  static getDerivedStateFromError(e) { return { e } }
  render() { return this.state.e ? <pre style={{ padding: 16, whiteSpace: 'pre-wrap', color: '#b3261e' }}>Something went wrong: {String(this.state.e?.message || this.state.e)}</pre> : this.props.children }
}
createRoot(document.getElementById('root')).render(<Boundary><App /></Boundary>)
