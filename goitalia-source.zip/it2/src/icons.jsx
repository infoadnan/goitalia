import { GLYPH } from './glyphs.js'
const S = (p, w = 2) => (props) => <svg className="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>{p}</svg>
export const I = {
  bus: S(<><rect x="4" y="3" width="16" height="14" rx="3.5" /><path d="M4 11h16M8 17v3M16 17v3" /><circle cx="8" cy="14" r=".6" /><circle cx="16" cy="14" r=".6" /></>),
  metro: S(<><rect x="5" y="3" width="14" height="14" rx="4" /><path d="M5 11h14M8 21l2-4M16 21l-2-4" /></>),
  tram: S(<><rect x="5" y="5" width="14" height="12" rx="3" /><path d="M5 11h14M9 3h6M9 21l2-4M15 21l-2-4M12 3v2" /></>),
  train: S(<><rect x="5" y="3" width="14" height="14" rx="4" /><path d="M5 10h14M8 21l2-4M16 21l-2-4" /><circle cx="9" cy="13.5" r=".6" /><circle cx="15" cy="13.5" r=".6" /></>),
  ferry: S(<><path d="M3 17l2 3c2 0 2-1 4-1s2 1 4 1 2-1 4-1 2 1 4 1l2-3-9-3z" /><path d="M7 14V9h10v5M12 9V4" /></>),
  other: S(<><path d="M4 18h16M6 18l3-12h6l3 12" /><path d="M9 11h6" /></>),
  walk: S(<><circle cx="13" cy="4.5" r="1.8" /><path d="M10 21l2-6-2-3 1-4 4 2 2 3M11 8l-3 3 1 3" /></>),
  dirs: () => <svg className="ic wide" viewBox="0 0 28 14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="4.5" cy="7" r="3" fill="currentColor" /><circle cx="23.5" cy="7" r="3" fill="currentColor" /><path d="M10 7h8m-3-3 3 3-3 3" /></svg>,
  route: S(<><circle cx="6" cy="18" r="2.4" /><circle cx="18" cy="6" r="2.4" /><path d="M8.4 18H15a3 3 0 000-6H9a3 3 0 010-6h6.6" /></>),
  loc: S(<><path d="M12 21s7-5.7 7-11a7 7 0 10-14 0c0 5.3 7 11 7 11z" /><circle cx="12" cy="10" r="2.5" /></>),
  lines: S(<><circle cx="5" cy="12" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="19" cy="12" r="2" /><path d="M7 12h3M14 12h3" /></>),
  ticket: S(<><path d="M3 9a2 2 0 002-2h14a2 2 0 002 2v1a2 2 0 000 4v1a2 2 0 00-2 2H5a2 2 0 00-2-2v-1a2 2 0 000-4z" /><path d="M14 7v10" strokeDasharray="2 2.4" /></>),
  more: S(<><circle cx="5" cy="12" r="1.2" /><circle cx="12" cy="12" r="1.2" /><circle cx="19" cy="12" r="1.2" /></>, 2.6),
  star: ({ on }) => <svg className="ic" viewBox="0 0 24 24" fill={on ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinejoin="round" aria-hidden="true"><path d="M12 17.3 18.2 21l-1.6-7L22 9.2l-7.2-.6L12 2 9.2 8.6 2 9.2 7.4 14l-1.6 7z" /></svg>,
  refresh: S(<><path d="M20 12a8 8 0 1 1-2.6-5.9" /><path d="M20 4v5h-5" /></>, 2.4),
  nav: (p) => <svg className="ic" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}><path d="M12 2.2l8 18.6-8-4.3-8 4.3z" /></svg>,
  back: S(<path d="m15 5-7 7 7 7" />, 2.4),
  chev: S(<path d="m9 6 6 6-6 6" />, 2.6),
  arrow: S(<path d="M5 12h14m-5-5 5 5-5 5" />),
  warn: S(<><path d="M12 3 2 20h20z" /><path d="M12 10v4M12 17.5v.01" /></>),
  search: S(<><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>, 2.4),
  swap: S(<path d="M7 4v14m0 0-3-3m3 3 3-3M17 20V6m0 0-3 3m3-3 3 3" />),
  locate: S(<><circle cx="12" cy="12" r="4" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3" /></>),
  close: S(<path d="m6 6 12 12M18 6 6 18" />, 2.4),
  live: () => <svg className="ic rt" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" aria-hidden="true"><path d="M5 19a1 1 0 1 0 0-.01M5 12a7 7 0 0 1 7 7M5 5a14 14 0 0 1 14 14" /></svg>,
  user: S(<><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6" /></>),
  ext: S(<path d="M14 4h6v6M20 4 10 14M18 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1h5" />),
}
export const modeIcon = (cat) => (I[cat] || I.bus)

export const Glyph = ({ k, ...p }) => {
  const g = GLYPH[k] || '', d = /\sd="([^"]+)"/.exec(g)?.[1]
  return <svg className="ic" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" {...p}><path d={d} fillRule={/evenodd/.test(g) ? 'evenodd' : undefined} /></svg>
}
for (const k of Object.keys(GLYPH)) I[k] = (p) => <Glyph k={k} {...p} />
