// GoItalia live-data proxy for Roma Mobilità GTFS-Realtime.  Runs on Cloudflare Workers (free plan is enough), Deno Deploy, Vercel Edge, Bun.
//  - GitHub Pages can't run servers and the official files are not served with CORS headers, so the browser can't read them directly.
//  - This only proxies the two official feeds (it is not an open proxy), adds CORS, caches ~8 s at the edge, and filters by trip / route / stop
//    WITHOUT decoding the protobuf (cheap CPU), so the phone downloads a few hundred bytes instead of the whole ~MB feed.
//  - No API key is needed for these public feeds. If the provider ever requires one, set it as the secret RM_API_KEY (never in the browser).
import { filterFeed, needle, TAG, headerTimestamp } from '../src/live/filter.js'

const DEFAULTS = {
  VEHICLES_URL: 'https://romamobilita.it/sites/default/files/rome_rtgtfs_vehicle_positions_feed.pb',
  TRIPS_URL: 'https://romamobilita.it/sites/default/files/rome_rtgtfs_trip_updates_feed.pb',
  CACHE_SECONDS: 8, MAX_STALE_SECONDS: 600,
}
const lastGood = {} // per-isolate fallback copy of the last good upstream response

const cors = (req, env) => {
  const allow = (env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim()), o = req.headers.get('Origin')
  const origin = allow.includes('*') ? '*' : allow.includes(o) ? o : allow[0]
  return { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin', 'Access-Control-Allow-Methods': 'GET, OPTIONS', 'Access-Control-Expose-Headers': 'X-Feed-Timestamp, X-Fetched-At, X-Stale, X-Entities', 'Access-Control-Max-Age': '86400' }
}
const json = (o, status, h) => new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...h } })
const id = (v) => (typeof v === 'string' && /^[\w.\-: ]{1,64}$/.test(v) ? v : null) // ids are short tokens; reject anything else

async function upstream(kind, env, ctx) {
  const url = env[kind === 'vehicles' ? 'VEHICLES_URL' : 'TRIPS_URL'] || DEFAULTS[kind === 'vehicles' ? 'VEHICLES_URL' : 'TRIPS_URL']
  const ttl = +env.CACHE_SECONDS || DEFAULTS.CACHE_SECONDS
  try {
    const res = await fetch(url, { headers: env.RM_API_KEY ? { Authorization: `Bearer ${env.RM_API_KEY}` } : {}, cf: { cacheTtl: ttl, cacheEverything: true } })
    if (!res.ok) throw new Error('upstream HTTP ' + res.status)
    const buf = new Uint8Array(await res.arrayBuffer())
    if (!buf.length) throw new Error('empty feed')
    lastGood[url] = { buf, at: Date.now() }
    return { buf, at: lastGood[url].at, stale: 0 }
  } catch (e) {
    const g = lastGood[url], max = (+env.MAX_STALE_SECONDS || DEFAULTS.MAX_STALE_SECONDS) * 1000
    if (g && Date.now() - g.at < max) return { buf: g.buf, at: g.at, stale: Math.round((Date.now() - g.at) / 1000) }
    throw e
  }
}

export async function handle(req, env = {}, ctx) {
  const h = cors(req, env), u = new URL(req.url)
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: h })
  if (req.method !== 'GET') return json({ error: 'method not allowed' }, 405, h)
  if (u.pathname === '/health') return json({ ok: true, time: new Date().toISOString() }, 200, h)
  const m = /^\/rt\/(vehicles|trips)$/.exec(u.pathname)
  if (!m) return json({ error: 'not found' }, 404, h)
  const kind = m[1], trip = id(u.searchParams.get('trip')), route = id(u.searchParams.get('route')), stop = id(u.searchParams.get('stop'))
  if ([u.searchParams.get('trip'), u.searchParams.get('route'), u.searchParams.get('stop')].some((v) => v && !id(v))) return json({ error: 'bad id' }, 400, h)
  const needles = []
  if (trip) needles.push(needle(TAG.tripId, trip))
  if (route) needles.push(needle(TAG.routeId, route))
  if (stop) needles.push(needle(kind === 'trips' ? TAG.tuStopId : TAG.vpStopId, stop))
  if (!needles.length && !(kind === 'vehicles' && u.searchParams.get('all') === '1')) return json({ error: 'give ?trip= ?route= or ?stop= (vehicles also allows ?all=1)' }, 400, h)
  try {
    const up = await upstream(kind, env, ctx)
    const { body, total } = needles.length ? filterFeed(up.buf, needles, +env.MAX_ENTITIES || 300) : { body: up.buf, total: -1 }
    return new Response(body, { status: 200, headers: { ...h, 'content-type': 'application/x-protobuf', 'cache-control': `public, max-age=${+env.CACHE_SECONDS || DEFAULTS.CACHE_SECONDS}`, 'x-feed-timestamp': String(headerTimestamp(up.buf) ?? ''), 'x-fetched-at': String(Math.round(up.at / 1000)), 'x-stale': String(up.stale), 'x-entities': String(total) } })
  } catch (e) {
    return json({ error: 'upstream unavailable', detail: String(e.message || e) }, 502, h)
  }
}
export default { fetch: (req, env, ctx) => handle(req, env, ctx) }
