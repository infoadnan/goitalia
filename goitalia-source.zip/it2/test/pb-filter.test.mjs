import test from 'node:test'
import assert from 'node:assert/strict'
import { decodeFeed } from '../src/live/pb.js'
import { filterFeed, needle, TAG, headerTimestamp } from '../src/live/filter.js'
import { RT, encode, hdr } from './helpers.mjs'

const vehicle = (i, o = {}) => ({ id: 'e' + i, vehicle: { trip: { tripId: 'T' + i, routeId: 'R' + (i % 5), directionId: i % 2, startDate: '20261126', startTime: '08:00:00' }, position: { latitude: 41.9 + i / 1e4, longitude: 12.5 + i / 1e4, bearing: 270.5, speed: 7.25 }, currentStopSequence: 4, stopId: 'S' + i, currentStatus: 2, timestamp: 1790000000 + i, vehicle: { id: 'V' + i, label: 'ATAC ' + i }, occupancyStatus: 1, ...o } })
const tripUpd = (i) => ({ id: 'u' + i, tripUpdate: { trip: { tripId: 'T' + i, routeId: 'R' + (i % 5), directionId: 0, startDate: '20261126' }, vehicle: { id: 'V' + i }, stopTimeUpdate: [{ stopSequence: 3, stopId: 'S' + i, arrival: { delay: -120, time: 1790000100 }, departure: { delay: -100 } }, { stopSequence: 4, stopId: 'S9' + i, arrival: { delay: 300 } , scheduleRelationship: 1 }], timestamp: 1790000050, delay: -75 } })

test('decoder equals the official bindings (vehicles, floats, direction 0, unicode)', () => {
  const buf = encode({ header: hdr(1790000123), entity: [vehicle(1), vehicle(2, { vehicle: { id: 'è', label: 'Perché' } })] })
  const f = decodeFeed(buf), ref = RT.FeedMessage.decode(buf)
  assert.equal(f.header.timestamp, 1790000123); assert.equal(f.header.version, '2.0')
  assert.equal(f.entities.length, 2)
  const v = f.entities[0].vehicle, r = ref.entity[0].vehicle
  assert.equal(v.trip.tripId, 'T1'); assert.equal(v.trip.routeId, 'R1'); assert.equal(v.trip.directionId, 1); assert.equal(v.trip.startDate, '20261126')
  assert.ok(Math.abs(v.pos.lat - r.position.latitude) < 1e-9); assert.ok(Math.abs(v.pos.lon - r.position.longitude) < 1e-9)
  assert.equal(v.pos.bearing, r.position.bearing); assert.equal(v.pos.speed, r.position.speed)
  assert.equal(v.ts, 1790000001); assert.equal(v.stopId, 'S1'); assert.equal(v.status, 2); assert.equal(v.seq, 4)
  assert.equal(f.entities[1].vehicle.vehicle.label, 'Perché')
  assert.equal(f.entities[0].vehicle.trip.directionId, 1)
  assert.equal(decodeFeed(encode({ header: hdr(1), entity: [vehicle(2)] })).entities[0].vehicle.trip.directionId, 0) // 0 must survive
})
test('decoder: trip updates with negative delays and skipped stops', () => {
  const f = decodeFeed(encode({ header: hdr(1790000123), entity: [tripUpd(3)] })), u = f.entities[0].tripUpdate
  assert.equal(u.delay, -75); assert.equal(u.timestamp, 1790000050)
  assert.equal(u.stu[0].arrival.delay, -120); assert.equal(u.stu[0].arrival.time, 1790000100); assert.equal(u.stu[0].departure.delay, -100)
  assert.equal(u.stu[1].rel, 1); assert.equal(u.stu[1].stopId, 'S93'); assert.equal(u.trip.tripId, 'T3')
})
test('filter keeps the header and only matching entities (field-anchored)', () => {
  const entities = Array.from({ length: 60 }, (_, i) => vehicle(i))
  const buf = encode({ header: hdr(1790000999), entity: entities })
  let r = filterFeed(buf, [needle(TAG.tripId, 'T7')]); let d = RT.FeedMessage.decode(r.body)
  assert.equal(d.entity.length, 1); assert.equal(d.entity[0].vehicle.trip.tripId, 'T7'); assert.equal(+d.header.timestamp, 1790000999)
  r = filterFeed(buf, [needle(TAG.routeId, 'R3')]); d = RT.FeedMessage.decode(r.body); assert.equal(d.entity.length, 12)
  assert.ok(d.entity.every((e) => e.vehicle.trip.routeId === 'R3'))
  r = filterFeed(buf, [needle(TAG.vpStopId, 'S11')]); assert.equal(RT.FeedMessage.decode(r.body).entity.length, 1)
  assert.equal(filterFeed(buf, [needle(TAG.tripId, 'NOPE')]).total, 0)
  assert.equal(headerTimestamp(buf), 1790000999)
  // trip-updates stop filter
  const tb = encode({ header: hdr(5), entity: [tripUpd(1), tripUpd(2)] })
  assert.equal(RT.FeedMessage.decode(filterFeed(tb, [needle(TAG.tuStopId, 'S92')]).body).entity.length, 1)
  assert.ok(filterFeed(buf, [needle(TAG.tripId, 'T7')]).body.length < buf.length / 20, 'must be far smaller than the whole feed')
})
test('filter rejects corrupt feeds instead of looping', () => {
  const buf = encode({ header: hdr(1), entity: [vehicle(1)] })
  assert.throws(() => filterFeed(buf.subarray(0, buf.length - 5), [needle(TAG.tripId, 'T1')]))
})
