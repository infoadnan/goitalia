import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { build } from '../scripts/build-gtfs.mjs'
import { handle } from '../backend/worker.js'
import { makeRt, vehicleFor, tripUpdateFor } from '../src/live/rt.js'
import { makeStatic, resolveTrip, tripIdCandidates } from '../src/live/gtfs.js'
import { buildModel, analyse } from '../src/live/engine.js'
import { pointAt } from '../src/live/geo.js'
import { writeGtfs, zipDir, tmp, encode, hdr, epoch, NOW_YMD, STOP_AT } from './helpers.mjs'

const dir = tmp(), out = path.join(dir, 'gtfs'); writeGtfs(path.join(dir, 'src')); await build(zipDir(path.join(dir, 'src'), path.join(dir, 'g.zip')), out)
const st = makeStatic({ base: 'http://pages/gtfs/', fetchImpl: async (u) => { const f = path.join(out, u.replace('http://pages/gtfs/', '')); return fs.existsSync(f) ? new Response(fs.readFileSync(f)) : new Response('no', { status: 404 }) } })

const now = epoch('08:09:30')
const probe = buildModel(JSON.parse(fs.readFileSync(path.join(out, 'route', 'R163.json'))), 'T0800')
const p = pointAt(probe.line, (probe.stops[2].dist + probe.stops[3].dist) / 2 + 40)
const veh = encode({ header: hdr(now - 3), entity: [
  { id: '1', vehicle: { trip: { tripId: 'T0800', routeId: 'R163', directionId: 0, startDate: NOW_YMD }, position: { latitude: p.lat, longitude: p.lon, bearing: p.bearing, speed: 6.5 }, stopId: 'S3', currentStatus: 2, timestamp: now - 12, vehicle: { id: '8123', label: '8123' } } },
  { id: '2', vehicle: { trip: { tripId: 'T0830', routeId: 'R163' }, position: { latitude: 41.9, longitude: 12.5 }, timestamp: now - 12 } }] })
const trips = encode({ header: hdr(now - 3), entity: [{ id: 'u1', tripUpdate: { trip: { tripId: 'T0800', routeId: 'R163', startDate: NOW_YMD }, stopTimeUpdate: [{ stopId: 'S3', arrival: { delay: 150 } }], timestamp: now - 10 } }] })
const env = { ALLOWED_ORIGINS: '*', VEHICLES_URL: 'https://up/v.pb', TRIPS_URL: 'https://up/t.pb' }
globalThis.fetch = async (u) => new Response(String(u).includes('v.pb') ? veh : trips)
const rt = makeRt({ base: 'https://worker.test', fetchImpl: (u) => handle(new Request(u), env) })

test('Transitous trip id -> official GTFS trip: by embedded id, and by route+time+stops when the id differs', async () => {
  assert.ok(tripIdCandidates('20261126_08:00_it-rome_T0800').includes('T0800'))
  const stops = probe.stops.map((s, i) => ({ lat: s.lat, lon: s.lon, scheduledDeparture: new Date((epoch('08:00:20') + i * 240) * 1000).toISOString() }))
  let r = await resolveTrip(st, { name: '163', tripId: '20261126_08:00_it-rome_T0800' }, stops); assert.equal(r.how, 'id'); assert.equal(r.tripId, 'T0800')
  r = await resolveTrip(st, { name: '163', tripId: 'opaque-hash-123' }, stops); assert.equal(r.how, 'time+stops'); assert.equal(r.tripId, 'T0800')
  assert.equal((await resolveTrip(st, { name: '999', tripId: 'x' }, stops)).reason, 'route-not-in-gtfs')
  const off = stops.map((s) => ({ ...s, scheduledDeparture: new Date((epoch('13:00:00')) * 1000).toISOString() }))
  assert.equal((await resolveTrip(st, { name: '163', tripId: 'zzz' }, off)).reason, 'no-matching-trip')
})
test('end to end: worker -> client decode -> match -> LIVE GPS + REAL-TIME ETA for the right bus only', async () => {
  const [v, u] = await Promise.all([rt.get('vehicles', { trip: 'T0800' }), rt.get('trips', { trip: 'T0800' })])
  assert.ok(v.ok && u.ok); assert.equal(v.feed.entities.length, 1, 'only the requested trip is downloaded')
  const model = probe, vh = vehicleFor(v.feed, 'T0800'), tu = tripUpdateFor(u.feed, 'T0800')
  assert.equal(vehicleFor(v.feed, 'T0830'), null)
  const r = analyse({ model, vehicle: vh, tu, now, feedTs: v.feedTs })
  assert.equal(r.gps.status, 'live'); assert.equal(r.nextIdx, 3); assert.equal(r.etaSrc, 'realtime'); assert.equal(r.conflict, false)
  assert.ok(r.vehicle.lateral < 5, 'GPS lies on the route shape')
})
test('errors are reported, never faked: unconfigured, unreachable, HTTP error, corrupt body', async () => {
  assert.deepEqual(await makeRt({ base: '' }).get('vehicles', { trip: 'x' }), { ok: false, reason: 'no-proxy' })
  assert.equal((await makeRt({ base: 'https://w', fetchImpl: async () => { throw new TypeError('Failed to fetch') } }).get('vehicles', { trip: 'x' })).reason, 'unreachable')
  assert.equal((await makeRt({ base: 'https://w', fetchImpl: async () => new Response('', { status: 502 }) }).get('vehicles', { trip: 'x' })).ok, false)
  assert.equal((await makeRt({ base: 'https://w', fetchImpl: async () => new Response(new Uint8Array([0x0a, 0xff, 0xff, 0xff])) }).get('vehicles', { trip: 'x' })).ok, false)
})
