import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { execFileSync } from 'node:child_process'
import gtfs from 'gtfs-realtime-bindings'
import { makeLine, pointAt } from '../src/live/geo.js'
import { romeMidnightMs } from '../src/live/engine.js'
export const { transit_realtime: RT } = gtfs

// ---- a small test-only GTFS (geometry in Rome; NOT shipped with the app) ----
export const SHAPE = [[41.9040, 12.5200], [41.9055, 12.5260], [41.9070, 12.5320], [41.9095, 12.5380], [41.9130, 12.5420], [41.9170, 12.5440], [41.9185, 12.5400], [41.9160, 12.5380], [41.9120, 12.5350], [41.9090, 12.5300]]
const L = makeLine(SHAPE)
export const STOP_AT = [0.04, 0.2, 0.36, 0.52, 0.66, 0.82].map((f) => pointAt(L, f * L.len))
export function writeGtfs(dir, { dropStop, t0 = 8 * 3600 } = {}) {
  fs.mkdirSync(dir, { recursive: true })
  const w = (n, rows) => fs.writeFileSync(path.join(dir, n), rows.join('\n') + '\n')
  w('routes.txt', ['route_id,route_short_name,route_long_name,route_type,route_color', 'R163,163,"Cimitero, del Verano - Rebibbia",3,', 'R309,309,Tiburtina - Colli Aniene,3,1F6FB2'])
  w('stops.txt', ['stop_id,stop_name,stop_lat,stop_lon', ...STOP_AT.filter((_, i) => i !== dropStop).map((p, i) => `S${i},"STOP ${i}",${p.lat.toFixed(6)},${p.lon.toFixed(6)}`)])
  w('shapes.txt', ['shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence', ...SHAPE.map((p, i) => `SH1,${p[0]},${p[1]},${i + 1}`)])
  w('trips.txt', ['route_id,service_id,trip_id,trip_headsign,direction_id,shape_id', 'R163,WD,T0800,REBIBBIA,0,SH1', 'R163,WD,T0830,REBIBBIA,0,SH1', 'R309,WD,X1,COLLI,0,'])
  const rows = ['trip_id,arrival_time,departure_time,stop_id,stop_sequence']
  for (const [tid, tt0] of [['T0800', t0], ['T0830', t0 + 1800]]) STOP_AT.forEach((_, i) => { const t = tt0 + i * 240, h = (x) => new Date(x * 1000).toISOString().slice(11, 19); rows.push(`${tid},${h(t)},${h(t + 20)},S${i},${(i + 1) * 3}`) })
  rows.push('X1,09:00:00,09:00:00,S0,1', 'X1,09:05:00,09:05:00,S1,2')
  w('stop_times.txt', rows)
}
export function zipDir(dir, zip) { fs.rmSync(zip, { force: true }); execFileSync('zip', ['-jq', zip, ...fs.readdirSync(dir).map((f) => path.join(dir, f))]); return zip }
export const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'goit-'))

// ---- GTFS-RT feeds encoded with the OFFICIAL bindings (independent of our decoder) ----
export const encode = (obj) => RT.FeedMessage.encode(RT.FeedMessage.fromObject(obj)).finish()
export const hdr = (ts) => ({ gtfsRealtimeVersion: '2.0', incrementality: 0, timestamp: ts })
export const NOW_YMD = '20261126'
export const epoch = (hhmmss) => { const [h, m, s] = hhmmss.split(':').map(Number); return Math.round(romeMidnightMs(NOW_YMD) / 1000) + h * 3600 + m * 60 + s }
