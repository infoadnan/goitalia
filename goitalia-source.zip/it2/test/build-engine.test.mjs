import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { build } from '../scripts/build-gtfs.mjs'
import { buildModel, analyse, gpsQuality, buildEtas, TH, romeMidnightMs, guessServiceDate } from '../src/live/engine.js'
import { makeLine, snap, pointAt } from '../src/live/geo.js'
import { writeGtfs, zipDir, tmp, SHAPE, STOP_AT, epoch, NOW_YMD } from './helpers.mjs'

const dir = tmp(), out = path.join(dir, 'gtfs')
writeGtfs(path.join(dir, 'src')); const zip = zipDir(path.join(dir, 'src'), path.join(dir, 'g.zip'))
const idx = await build(zip, out)
const shard = JSON.parse(fs.readFileSync(path.join(out, 'route', 'R163.json')))
const model = buildModel(shard, 'T0800')

test('builder: index, shards, patterns share one shape, monotonic distances, delta-coded times', () => {
  assert.deepEqual(idx.byShort['163'], ['R163']); assert.equal(idx.counts.routes, 2); assert.equal(idx.counts.trips, 3)
  assert.equal(shard.patterns.length, 1); assert.equal(Object.keys(shard.trips).length, 2)      // two trips, one pattern
  const d = shard.patterns[0].dist; for (let i = 1; i < d.length; i++) assert.ok(d[i] > d[i - 1], 'distances increase')
  assert.ok(shard.shapes.SH1.length > 10)
  assert.equal(model.stops[0].sec, 8 * 3600); assert.equal(model.stops[5].sec, 8 * 3600 + 5 * 240)     // sequences 3,6,9.. were sorted numerically
  assert.equal(JSON.parse(fs.readFileSync(path.join(out, 'route', 'R309.json'))).patterns[0].shape, '') // trip without shape still builds
  assert.match(fs.readFileSync(path.join(out, 'index.json'), 'utf8'), /"generated"/)
})
test('builder: refuses a GTFS whose stop_times reference a missing stop', async () => {
  const d2 = tmp(); writeGtfs(path.join(d2, 's'), { dropStop: 2 }); const z = zipDir(path.join(d2, 's'), path.join(d2, 'g.zip'))
  await assert.rejects(() => build(z, path.join(d2, 'o')), /stop missing/)
})

const T0 = (hms) => epoch(hms)
const vehicleAt = (s, o = {}) => { const p = pointAt(model.line, s); return { pos: { lat: p.lat, lon: p.lon, bearing: p.bearing, speed: 6 }, ts: 0, status: 2, ...o } }
test('quality: live / delayed / stale / none / invalid', () => {
  const now = T0('08:10:00'), v = (age, pos = { lat: 41.9, lon: 12.5 }) => ({ pos, ts: now - age })
  assert.equal(gpsQuality(v(20), now).status, 'live'); assert.equal(gpsQuality(v(100), now).status, 'delayed')
  assert.equal(gpsQuality(v(400), now).status, 'stale'); assert.equal(gpsQuality(v(2000), now).status, 'none')
  assert.equal(gpsQuality(v(-500), now).status, 'invalid'); assert.equal(gpsQuality(v(5, { lat: 0, lon: 0 }), now).status, 'invalid')
  assert.equal(gpsQuality(v(5, { lat: 51.5, lon: -0.1 }), now).reason, 'bad-coordinates'); assert.equal(gpsQuality(null, now).status, 'none')
  assert.equal(gpsQuality({ pos: { lat: 41.9, lon: 12.5 } }, now, now - 10).tsSource, 'feed')
})
test('route-based matching: GPS between stops 2 and 3 -> next stop 3, snapped within metres, official ETA labels', () => {
  const now = T0('08:09:30'), s = (model.stops[2].dist + model.stops[3].dist) / 2
  const v = vehicleAt(s, { ts: now - 20 }); v.pos.lat += 0.00006   // ~7 m off the line
  const r = analyse({ model, vehicle: v, tu: null, now, feedTs: now - 5 })
  assert.equal(r.gps.status, 'live'); assert.equal(r.nextIdx, 3); assert.ok(Math.abs(r.vehicle.s - s) < 25, `snapped ${r.vehicle.s} vs ${s}`); assert.ok(r.vehicle.lateral < 15)
  assert.equal(r.etaSrc, 'scheduled'); assert.equal(r.etas[3].src, 'scheduled')
  assert.equal(r.etas[3].time, romeMidnightMs(NOW_YMD) + model.stops[3].sec * 1000)
  const tu = { trip: { tripId: 'T0800', startDate: NOW_YMD }, stu: [{ stopId: 'S3', arrival: { time: T0('08:15:00') } }] }   // sched 08:12 -> 3 min late
  const r2 = analyse({ model, vehicle: v, tu, now, feedTs: now - 5 })
  assert.equal(r2.etaSrc, 'realtime'); assert.equal(r2.etas[3].src, 'realtime'); assert.equal(r2.etas[3].time, T0('08:15:00') * 1000)
  assert.equal(r2.etas[4].src, 'realtime-propagated'); assert.equal(r2.etas[4].time, romeMidnightMs(NOW_YMD) + model.stops[4].sec * 1000 + 180000)   // delay carried downstream
  assert.equal(r2.etas[0].src, 'scheduled')
})
test('ETA: delay-only updates, negative delay, skipped stop, cancelled trip, never going backwards', () => {
  const now = T0('08:00:00'), mid = romeMidnightMs(NOW_YMD)
  let e = buildEtas(model, { trip: { startDate: NOW_YMD }, stu: [{ stopId: 'S1', arrival: { delay: -60 } }] }, now * 1000)
  assert.equal(e.etas[1].time, mid + model.stops[1].sec * 1000 - 60000); assert.equal(e.etas[2].time, mid + model.stops[2].sec * 1000 - 60000)
  e = buildEtas(model, { trip: { startDate: NOW_YMD }, stu: [{ stopId: 'S2', rel: 1 }, { stopId: 'S3', departure: { delay: 120 } }] }, now * 1000)
  assert.equal(e.etas[2].skipped, true); assert.equal(e.etas[3].src, 'realtime')
  assert.equal(buildEtas(model, { trip: { rel: 3 }, stu: [] }, now * 1000).cancelled, true)
  e = buildEtas(model, { trip: { startDate: NOW_YMD }, stu: [{ stopId: 'S1', arrival: { delay: 600 } }, { stopId: 'S2', arrival: { delay: -300 } }] }, now * 1000)
  assert.ok(e.etas[2].time >= e.etas[1].time, 'times never decrease')
  e = buildEtas(model, { trip: { startDate: NOW_YMD }, stu: [], delay: 90 }, now * 1000); assert.equal(e.etas[4].src, 'realtime-propagated')
  assert.equal(buildEtas(model, null, now * 1000).official, false)
})
test('official current stop is used when it agrees with the geometry, geometry wins when it does not', () => {
  const now = T0('08:08:10'), v = vehicleAt(model.stops[2].dist + 2, { ts: now - 10, stopId: 'S2', status: 1 })
  v.pos.speed = 0
  let r = analyse({ model, vehicle: v, tu: null, now }); assert.equal(r.nextIdx, 2); assert.equal(r.atStop, true); assert.equal(r.conflict, false)
  r = analyse({ model, vehicle: { ...v, stopId: 'S5' }, tu: null, now }); assert.equal(r.conflict, true); assert.equal(r.nextIdx, 3)
})
test('GPS off the route is flagged and not used for the next stop; outliers and jumps are rejected', () => {
  const now = T0('08:09:00'), far = { pos: { lat: 41.95, lon: 12.60, bearing: 0, speed: 5 }, ts: now - 5 }
  let r = analyse({ model, vehicle: far, tu: null, now }); assert.equal(r.vehicle.offRoute, true); assert.equal(r.nextIdx, null)
  const a = analyse({ model, vehicle: vehicleAt(1000, { ts: now - 30 }), tu: null, now })
  const teleport = analyse({ model, vehicle: vehicleAt(model.line.len - 100, { ts: now - 20 }), tu: null, now, prev: a.state })
  assert.equal(teleport.vehicle.rejected, true); assert.ok(Math.abs(teleport.vehicle.s - a.vehicle.s) < 1)
  const back = analyse({ model, vehicle: vehicleAt(800, { ts: now - 10 }), tu: null, now, prev: a.state })
  assert.equal(back.vehicle.rejected, true)
  const ok = analyse({ model, vehicle: vehicleAt(1080, { ts: now - 10 }), tu: null, now, prev: a.state }); assert.ok(!ok.vehicle.rejected); assert.ok(ok.vehicle.s > 1060)
})
test('stale GPS is never presented as live, but the official ETA still works', () => {
  const now = T0('08:20:00'), tu = { trip: { startDate: NOW_YMD }, stu: [{ stopId: 'S4', arrival: { time: T0('08:22:00') } }] }
  const r = analyse({ model, vehicle: vehicleAt(2000, { ts: now - 400 }), tu, now }); assert.equal(r.gps.status, 'stale'); assert.equal(r.etaSrc, 'realtime')
  const r2 = analyse({ model, vehicle: null, tu, now }); assert.equal(r2.gps.status, 'none'); assert.equal(r2.vehicle, null); assert.equal(r2.nextIdx, null)
})
test('heading disambiguates a route that returns along the same street', () => {
  const A = [[41.90, 12.50], [41.90, 12.51], [41.90, 12.52], [41.90005, 12.52], [41.90005, 12.51], [41.90005, 12.50]], line = makeLine(A)
  const p = [41.90003, 12.505]
  assert.ok(snap(line, p, { heading: 90, speed: 6 }).s < line.len / 2); assert.ok(snap(line, p, { heading: 270, speed: 6 }).s > line.len / 2)
  assert.ok(snap(line, p, { from: line.len / 2 - 50 }).s > line.len / 2 - 60) // window keeps it on the second half
})
test('service date: start_date wins; otherwise nearest day to now (trips after midnight)', () => {
  assert.equal(guessServiceDate(8 * 3600, epoch('08:10:00') * 1000), NOW_YMD)
  assert.equal(guessServiceDate(25 * 3600, epoch('00:30:00') * 1000), '20261125')   // 25:00 belongs to yesterday's service day
})
