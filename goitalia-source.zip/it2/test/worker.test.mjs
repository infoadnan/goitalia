import test from 'node:test'
import assert from 'node:assert/strict'
import { handle } from '../backend/worker.js'
import { RT, encode, hdr } from './helpers.mjs'

const feed = encode({ header: hdr(1790000500), entity: Array.from({ length: 30 }, (_, i) => ({ id: 'e' + i, vehicle: { trip: { tripId: 'T' + i, routeId: 'R' + (i % 3) }, position: { latitude: 41.9, longitude: 12.5 }, timestamp: 1790000400, stopId: 'S' + i } })) })
const env = { ALLOWED_ORIGINS: 'https://me.github.io', VEHICLES_URL: 'https://up/v.pb', TRIPS_URL: 'https://up/t.pb' }
const req = (p, o = {}) => new Request('https://worker.test' + p, o)
let up = { ok: true }
globalThis.fetch = async () => (up.ok ? new Response(feed, { status: 200 }) : new Response('x', { status: 500 }))

test('serves a filtered protobuf with CORS, caching and feed-timestamp headers', async () => {
  const r = await handle(req('/rt/vehicles?trip=T4', { headers: { Origin: 'https://me.github.io' } }), env)
  assert.equal(r.status, 200); assert.equal(r.headers.get('access-control-allow-origin'), 'https://me.github.io')
  assert.equal(r.headers.get('x-feed-timestamp'), '1790000500'); assert.equal(r.headers.get('x-entities'), '1'); assert.match(r.headers.get('cache-control'), /max-age=8/)
  assert.equal(RT.FeedMessage.decode(new Uint8Array(await r.arrayBuffer())).entity[0].vehicle.trip.tripId, 'T4')
})
test('other origins do not get a CORS grant', async () => {
  const r = await handle(req('/rt/vehicles?trip=T4', { headers: { Origin: 'https://evil.example' } }), env)
  assert.notEqual(r.headers.get('access-control-allow-origin'), 'https://evil.example')
})
test('preflight, health, unknown path, bad ids and missing filters', async () => {
  assert.equal((await handle(req('/rt/vehicles', { method: 'OPTIONS' }), env)).status, 204)
  assert.equal((await handle(req('/health'), env)).status, 200)
  assert.equal((await handle(req('/other'), env)).status, 404)
  assert.equal((await handle(req('/rt/vehicles?trip=' + encodeURIComponent('../../etc/passwd')), env)).status, 400)
  assert.equal((await handle(req('/rt/trips'), env)).status, 400)
  assert.equal((await handle(req('/rt/vehicles', { method: 'POST' }), env)).status, 405)
})
test('it is not an open proxy: only the two configured feeds are ever fetched', async () => {
  const seen = []; const old = globalThis.fetch; globalThis.fetch = async (u) => { seen.push(String(u)); return new Response(feed) }
  await handle(req('/rt/vehicles?route=R1&url=https://evil.example/x'), env); await handle(req('/rt/trips?trip=T1'), env)
  globalThis.fetch = old
  assert.deepEqual(seen.sort(), ['https://up/t.pb', 'https://up/v.pb'])
})
test('upstream failure: last good copy is served as stale; with nothing cached it is a clean 502', async () => {
  up = { ok: true }; await handle(req('/rt/vehicles?trip=T1'), env)          // primes the cache
  up = { ok: false }
  const r = await handle(req('/rt/vehicles?trip=T1'), env)
  assert.equal(r.status, 200); assert.ok(+r.headers.get('x-stale') >= 0 && r.headers.has('x-stale'))
  const r2 = await handle(req('/rt/trips?trip=T1'), { ...env, TRIPS_URL: 'https://up/never.pb' })
  assert.equal(r2.status, 502); assert.equal((await r2.json()).error, 'upstream unavailable')
})
